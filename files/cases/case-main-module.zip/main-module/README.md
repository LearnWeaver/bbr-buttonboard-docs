# main-module-xiao openGrid case

A 2x1 openGrid case (55.5 × 27.5 × 15.0 mm, plus 3.4 mm of snaps) for the 50 × 20 XIAO carrier.
`mm_case.py` (CadQuery) generates everything from the board's KiCad coordinates: `python3 mm_case.py .`

- **Base**: the board drops in face-up onto the floor. A rib under the XIAO overhang locates the west edge.
  Two openGrid snaps on the back are lite depth (3.4 mm), so the case fits both lite and full boards.
- **Lid**: 1.6 mm, flush with the walls at 15.0 mm, the top every case shares (IMPLEMENTATION.md §56). It drops
  into a pocket 0.8 mm in from the outside and snaps in on two hooked tabs, one on each long wall at KiCad
  x 103–119, clear of the posts and J2/J3. A pry notch in the east end lifts it out.
  Four posts hold the board down on bare carrier copper. They keep their old section through the 5.6 mm
  parts zone and widen by 1 mm a side above it. There is a Ø4 poke hole over SW3 (`SW3_HOLE`), in a
  Ø6 sleeve that comes down to 5.6 mm over the board, so a pin still meets SW3 0.6 mm below the hole.
  A Ø3 window over the XIAO's NeoPixel, the status light that flashes (`PIXEL_HOLE`), at KiCad (119.5, 90):
  a Ø5 tube carries the light from 1.0 mm above the LED up through the lid, clear of the XIAO's two
  buttons either side of it. The position comes from Seeed's XIAO RP2040 model as placed on the carrier.
- **Heights**: board on the floor, 1.6–3.2 as before. The lid's underside is at 13.4, so there is 10.2 mm
  over the board, where there was 5.6.
- **Openings**: USB-C 13.0 × 7.4 with r1.5 corners, sized for cable overmolds because the receptacle sits
  about 2 mm behind the outer face. J2 and J3 each get a 12.8 × 4.85 window through the last 1.0 mm of wall,
  with a 16 mm relief outside it so the GH latch can be squeezed.
- **Print**: base floor-down, snaps on the bed; the floor overhangs the snaps by ~1.3 mm at the edges.
  Lid top-down; the STL is already flipped. PETG or PLA, 0.2 mm layers.
- **Assumed, not measured**: XIAO height 3.5 mm overall, USB-C centre ~1.7 mm above the carrier.
  Check these on the first print.

openGrid snap geometry follows morganp/openscad-opengrid (MIT), from openGrid (CC BY 4.0, David D).
