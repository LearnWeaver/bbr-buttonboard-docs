# splitter openGrid case

A 1x1 openGrid case for the 20 × 20 bus splitter: 27.5 × 27.5 × 15.0 mm, plus one snap 3.4 mm deep.
`splitter_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 splitter_case.py .`

- **Base**: the board's back has nothing on it but vias and the identity text, so it sits flat on a
  1.3 mm ledge ring 1.0 mm off the floor (PCB 2.6–4.2, as before). The walls are 3.6 mm thick.
- **Slots**: each wall has a 10.4 mm slot at its connector, from just below the PCB's top face to the
  top of the case. The connectors are a pinwheel, so each slot is 3.22 mm off its wall's centre line.
  That is J2 west of centre on the north wall, J3 north of centre on the east wall, J4 east of centre
  on the south wall and J1 south of centre on the west wall.
- **Lid**: flat, 1.5 mm, flush with the walls at 15.0 mm, the top every case shares (IMPLEMENTATION.md §56);
  it drops into a pocket 0.8 mm in from the outside. A tongue closes each slot from 0.2 mm above the lead
  up to the top face. A 3 mm post, now 9.2 mm long, locates the board's centre, 0.1 mm clear of it. The lid
  snaps in on two hooked tabs, on the stretches of the north and south walls that have no slot (x 2.9 to
  9.7 on the north, −9.7 to −2.9 on the south). A pry notch in the east wall, south of J3's slot, lifts it out.
- **Assembly**: plug every lead into the board first, drop the board in with the leads in their slots,
  then snap the lid in. Leave unused ports empty, or put a terminator in one if this splitter is at an
  end of the bus (PROTOCOL.md §1.3).
- **Unverified**: the slot size (10.4 × 5.0 mm above the PCB) is from the GH datasheet's nominal plug
  dimensions, not from a real GHR-06V-S lead. Check one before printing a batch.
- **Print**: base floor-down, snap on the bed. Lid top-down; the STL is already flipped.
