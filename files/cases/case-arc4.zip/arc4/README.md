# tile-arc4 openGrid case

A 2x1 openGrid case for the 50 × 25 arc4 r2 board: 55.5 × 27.5 × 15.0 mm, plus two snaps 3.4 mm deep.
`arc4_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 arc4_case.py .`

- **The buttons are not in the case.** They panel-mount elsewhere and reach the board on four 3-pin JST PH
  leads (IMPLEMENTATION.md §31). The case only holds the board.
- **North wall**: open from the board top to the lid underside over all four PH connectors (J3–J6), so each
  plug goes in from the side. The plugs stand a few mm proud of the case's north face. There is no wall above
  the opening, so there the lid runs out to the case's north face.
- **Zip-tie anchor in the lid**: PH plugs have no latch, so r1 had a zip-tie anchor on the board, which r2 has
  no room for (IMPLEMENTATION.md §47): the case does the strain relief, and this is it. It moved into the lid:
  two 1.8 × 4.0 mm slots in the top face, 7 mm apart, joined by a tunnel inside the lid. Thread the tie down one slot, through, and up the other, then round
  the four leads folded back over the lid. It takes ties up to about 3.6 mm wide. Nothing goes through the
  lid's underside.
- **Lid**: 3.0 mm thick, for the tie tunnel. Flush with the walls at 15.0 mm, the top every case shares
  (IMPLEMENTATION.md §56); it drops into a pocket 0.8 mm in from the outside. Its underside is at 12.0, 7.8 mm
  above the board (PCB 2.6–4.2, as before), so the 5.5 mm PH bodies leave 2.3 mm under it. J1 and J2 are open
  from above at the ends, with latch relief, as on the other cases.
- **Snap latches**: three hooked tabs. One on the south wall, x −10 to 10, between J1 and J2. One on each end
  wall north of the J1/J2 openings, y 2.5 to 11, where it passes 1.1 mm outboard of the J3/J6 PH bodies.
  The south groove leaves 0.5 mm of the 1.1 mm wall. There is no separate pry notch: the J1/J2 cut-outs
  leave the lid's end edges open, with 3.5 mm of room under them.
- **Base**: the board rests on ledges under its two short ends. Only the test pads are on the back, so 1.0 mm
  under it is enough.
- **Walls are 1.1 mm** along the long sides: a 25 mm board in a 28 mm cell leaves no more, as on
  tile-mx1-1x1. Print with at least 3 perimeters at 0.4 mm.
- **Assembly**: board into the base, snap the lid in, plug the four leads in from the north, then tie them.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped. The tunnel roof
  bridges 8.8 mm.
- The back-side test pads are covered by the base, so program the board before casing it.
