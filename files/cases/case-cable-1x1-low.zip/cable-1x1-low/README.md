 cable-1x1: openGrid filler and cable guide

A 1x1 openGrid tile with no PCB in it. It fills an empty cell, and it guides and holds the bus leads that
run between tiles. Each variant is 27.5 × 27.5 × 15.0 mm, plus one snap 3.4 mm deep: the same envelope as
the other 1x1 cases, and the same flush snap-in lid (IMPLEMENTATION.md §56), so a cable tile reads like
its neighbours. `cable_1x1.py` (CadQuery) builds every variant and reuses the snap and lid from
`../main-module-xiao/case/mm_case.py`.

Run `python3 cable_1x1.py .`. It writes, for each variant, `cable_1x1_<variant>_base.step/.stl` and
`_lid.step/.stl` (the lid STL flipped, top on the bed), and `cable_1x1_blank.step/.stl` as one piece. It
also writes `cable_1x1_assembly.step`, all five side by side with their lids, for Fusion. It checks that
every part is one valid solid and that base and lid do not overlap. The STEP and STL files are build
output, so do not commit them.

`python3 cable_1x1.py . --open` builds the earlier lid-free versions instead (`*_open*`): channels open
to the top, a lead pressed in from above and held by fixed fingers. Use them where you change leads often.

![preview](cable_1x1_preview.png)

| Variant | Channel | Latches |
|---|---|---|
| `blank` | none: one solid piece, with the lid outline cut 0.4 mm into its top so it reads like the others | none |
| `straight` | west to east, centred | N and S walls, x −4..4; pry notch N at x 9 |
| `corner` | south to east, 5 mm inner radius, square outer corner | N x −4..4, S x −11..−7; pry notch W |
| `tee` | west to east, with a stem to the south | N x −4..4, S x ±7..11; pry notch N at x 9 |
| `cross` | west to east and south to north | N x 7..11, S x −11..−7; pry notch N at x −9 |
| `drop` | west to east, plus an 11 mm hole through the floor and the snap at the centre, so a lead comes up from behind the openGrid board and leaves by either wall | N and S walls, x −4..4; pry notch N at x 9 |

To get the other orientations, turn the tile in the grid. The snap is square, so all four turns fit.

Every channel is a tunnel 9.0 mm wide and 11.9 mm high, from the floor (z 1.6) to the lid's underside
(z 13.5). It is open only at the tile edges, with a 1 mm lead-in at each mouth. The lid is 1.5 mm thick.

## Low tiles for the back of the board: `--low`

`python3 cable_1x1.py . --low` builds thin versions of every variant but blank, a quarter of the case height:
3.75 mm above the board face, plus the snap. They snap into the **back** of the openGrid board and carry leads
behind the panel. **Every** low tile has the front `drop` tile's 11 mm centre hole through its floor and snap,
where its channels meet, so a lead can come through the board at any of them: in one cell, a front drop tile
over any back tile passes a lead straight through. Files are `cable_1x1_<variant>_low_*`.

- **Section:** 0.6 mm floor, a 9.0 × 2.35 mm tunnel, and a 0.8 mm flush lid. Two flat ribbons fit stacked; a
  round bundle (about 3.3 mm) and a GH plug (4.3 mm tall) do not. Route the lead, then plug it.
- **Fits under the back plate** (`../back-plate`, 5 mm gap, 1.25 mm to spare), so the two can share an
  area.
- **Lid:** the shared flush snap-in lid at the low height, with 2.2 mm latch tabs in pockets in the solid
  parts, on the same walls as the full-height tiles.
- **Needs a full openGrid board.** A snap is 3.4 mm deep and a full board is 6.8 mm, so a front tile and a
  back tile share a cell exactly. A lite board is single-sided and has no back to snap into. Check the fit
  of a front and a back snap in the same cell on your board before printing a set.

## Parameters

| Name | Value | What |
|---|---|---|
| `OUT` | 27.5 | outside size: one cell less 0.5 mm, the same as every 1x1 case |
| `CORNER_R` | 2.0 | vertical corner radius, the same as the other cases |
| `H` | 15.0 | height of the top: `TOP_Z`, shared by every case; overridden by the 2nd argument |
| `FLOOR` | 1.6 | height of the channel floor: the floor of every case |
| `W` | 9.0 | channel width |
| `R_IN` | 5.0 | inner radius at every turn (the island corners) |
| `MOUTH_C` | 1.0 | 45° lead-in chamfer on the channel walls at the tile edge |
| `LID_T` | 1.5 | lid thickness |
| `LOW` | 3.75 / 0.6 / 0.8 / 2.2 | `--low`: height, floor, lid and latch length of the back-of-board tiles |
| `WALL` | 1.6 | outer wall behind a latch pocket |
| `LATCHES`, `PRY` | table | latch spans and the pry notch per variant |
| `FINGER_C`, `FINGER_T`, `FINGERS` | 4.5, 1.2, table | `--open` only: the fingers of the lid-free versions |

## Design choices

- **Retention: a lid.** Lay the lead in the channel, then snap the lid on; no plug has to thread
  through, and you can change a lead without unplugging either end by popping the lid. The lid holds a
  flat ribbon and a loose bundle equally well. It is the shared flush top of every case: hooked tabs snap
  into grooves, and a pry notch lifts it out.
  - **Latch pockets.** The tabs hang into small pockets cut in the solid parts of the tile, 1.6 mm in from
    the outside, so they never sit in a channel against a lead.
  - **The rim stays whole.** Each channel stops at the lid's underside, so the edge openings are windows
    below the lid, and the 0.8 mm rim round the top is unbroken.
  - **Earlier version.** The first design had open channels with fixed 45° fingers instead of a lid
    (`--open`). It was changed so that cable tiles match the lidded cases in a panel.
- **Channel height.** The floor is at z 1.6, the floor of every case, and the tunnel rises to the lid's
  underside at z 13.5. Where each tile's connector body sits, with the boards at their §56 heights:

  | Tile | Connector body above the grid (z) | How the lead leaves |
  |---|---|---|
  | disp1 | 2.1–6.35 (GH hanging under the upside-down board) | low: runs straight in |
  | mx1-1x1, mx1rgb-1x1 | 4.15–8.4 (GH hanging under the board) | runs straight in |
  | disp2 | 4.65–8.9 (GH on the board's back) | runs straight in |
  | main-module-xiao | 3.2–7.45 | runs straight in |
  | splitter, arc4 | 4.2–8.45 | runs straight in |
  | screenkey1 | 5.8–10.05 | runs straight in |
  | enc1, enc2 | 6.45–10.7 | runs straight in |
  | mx1rgb, mx3rgb, mx4 | 10.0–14.25, from a slot open to the top | drops about 3 mm to the tunnel |

  Every lead leaves its plug well inside the tunnel's 1.6–13.5. On the MX tiles the plug's top stands above
  the tunnel, but the plug stays in its own case; only the lead crosses.
- **Capacity.** The 9 × 11.9 mm tunnel takes several ribbons stacked, or two loose bundles side by side.
- **The corner keeps its outer corner square, on purpose.** A flat ribbon cannot bend edgewise. To turn
  90° flat it is folded at 45°, and the fold fills a square corner, not an arc. So the outer wall is
  square, and the inner (island) corner has a 5 mm radius for a round bundle. The tee and the cross use
  the same 5 mm island radius. A folded ribbon is 2.2 mm thick at the fold.
- **Plugs.** A plug does not have to pass through anything. A GH plug (about 8 mm wide) also fits the
  9 mm channel. The mouth chamfer widens each mouth to 11 mm at the edge, which leaves room for a plug
  tail that sticks out of a thin-walled neighbour such as mx1-1x1.
- **Printability.** Base flat on the bed, snap down, as every case base. Lid top-down; its tabs point up.

## Not verified / open

- **Lead size is from the brief, not measured.** Ribbon 6.5–7 × 1.1 mm, wires 1.0–1.1 mm OD, plug about
  8.0 × 4.3 × 6 mm. The splitter case allows 10.4 mm for a GHR-06V-S with its lead, and that is wider
  than 9 mm. It does not matter here, because no plug passes through, but measure a real lead before
  you print a batch.
- **The latch fit is untested**, as on every case (§56). The tabs and grooves are the shared ones.
- **Off-centre connectors.** The channels are centred, which lines up with the end connectors of mx1rgb,
  mx3rgb, enc1, disp1 and screenkey1. Some connectors are off the cell centre:
  - arc4 J1/J2: 6 mm off.
  - mx4: 4.5 mm off.
  - mx1-1x1: two leads side by side, about ±6 mm.
  - enc2 and disp2: off their cells' centres.

  A ribbon from any of these has to twist or fold to reach the channel, because it cannot jog sideways
  flat. A `straight` with an offset channel would be an easy variant to add if this proves awkward.
- **Height.** H is `TOP_Z`, 15.0 mm, the top of every case, so a cable tile sits level with its neighbours.
