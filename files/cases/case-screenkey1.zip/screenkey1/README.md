# tile-screenkey1 openGrid case

A 2x1 openGrid case for the 50 × 22 screenkey1 board: 55.5 × 27.5 × 15.0 mm, plus two snaps 3.4 mm deep.
The Waveshare 0.85" ScreenKey module stands on top of the lid; with it fitted the keycap top is 36.0 mm above
the openGrid face. `sk1_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 sk1_case.py .`

- **Three parts: base, lid, hood.** The module stands on the lid, and the hood drops over it and pegs into the lid.
- **Flush snap-in lid** (IMPLEMENTATION.md §56): the walls rise to 15.0, the height every case shares, and the lid
  drops into a pocket 0.8 mm in from the outside and finishes flush with them. Hooked tabs under it snap into
  grooves: two on the north wall either side of the J3 slot (x ±12..22) and two on the south wall (x ±6..22).
  To open it, take the hood off, then lever the lid up at the notch in the south rim, at x = 0.
  The module and hood stand above 15.0, like a keycap.
- **Hood**: 39.6 × 28.0 × 9.6 mm. It wraps the module's sides from the lid up to the top of its switch plate.
  A 1.2 mm lip over the plate's rim holds the module down, and the keycap passes through a 25.9 × 22.7 opening
  (0.4 mm clear each side). The lip has Ø4.4 holes over the plate's four M2 screw heads. Its long walls are only
  0.84 mm (two print lines): the module is 26.01 wide, and `HOOD_W` = 28.0 keeps them within one openGrid
  cell. The end walls are 2.0 and carry four Ø2.0 pegs that press into the lid.
  A 20 mm window in the north wall, under the carrier, lets the 9-pin plug out. Fit the module, plug the cable
  in, then press the hood on.
- **The module stands on the lid, inside the hood.** Its carrier is 26.01 × 35.31 mm, too wide to go inside the
  base, so it sits above it. It lies along the case's length, centred.
- **Lid**: 3.5 mm thick, with four sockets 3.0 mm deep that the module's own brass standoffs press into. The
  top stays flat, so the lid prints top-down with no support. Thinner, the sockets would need raised bosses.
  A key press pushes the standoffs into their sockets, so the load goes into the case and no screws are needed.
  Screw heads under the lid would land in the side walls. Add a drop of glue if the fit is loose.
- **Base**: the board rests on ledges under its two short ends, with 2.6 mm under it for the back-side chips
  (U5's SOIC-8 flash is the tallest, 2.16 mm). The board stays low (front at 5.8), so the lid's underside is 5.7
  above it and the tabs hang 1.5 mm clear of the front parts. J1/J2 tops sit 5.0 below the case top.
- **J1 and J2**: open from the board top up through the lid at each end, as on the other cases, with latch relief.
  The slots are 2.7 mm deeper than before the flush top.
- **J3 (the module cable)**: its mouth is on the board's north edge, so the north wall and the lid are cut away
  over it, and the plug goes in from the side. Turn the module so its 9-pin socket faces north, and run the
  cable down the north face into J3. The cable shows; `sk1_bay_case.py` is the variant that hides it.
- **The module's cable is 200 mm**, far more than the ~30 mm this needs. Coil the slack beside the module, or
  make a short lead: a PicoBlade 51021-0900 housing with crimped wires at each end (reversed for r1, see
  IMPLEMENTATION.md §34.17).
- **Print**: base floor-down, snaps on the bed. Lid and hood top-down; both STLs are already flipped. The lid's top is one flat
  face, so the sockets print as plain holes from the bed.
- The back-side UPDI test pads are covered by the base, so program the board before casing it.

## Cable-bay variant: `sk1_bay_case.py`

The same case with the cable hidden. Run `python3 sk1_bay_case.py .`, which writes `sk1_bay_case_*`. Both
9-pin plugs stick out north, J3's from the board and the module's from under its carrier, each about 7 mm with
its cable bend. A 2x1 cell has no room for that. So base, lid and hood all grow 8 mm north (`BAY_D`) into a
closed bay, and the case becomes 55.5 × 35.5. The hood is 39.6 × 35.8 and has no plug window.

- The snaps stay on the 2x1 cell, but the case covers part of the cell to its north, so no tile can sit
  directly north of it.
- Inside the base, a 1.2 mm wall with a window over J3 keeps the board in place. The cable runs from J3 up
  through a slot in the lid into the hood, where it meets the module's plug. None of it shows.
- The bay is only 6.5 mm deep, so the 200 mm cable will not fit. Make a ~40 mm lead.
- Fit order: plug J3, drop the board in, click the lid on, plug the module and press it into its sockets, then
  press the hood on.
- Latches: two on the bay's outer wall, either side of the cable (x ±12..22), and two on the south wall as on
  the 2x1 case; the pry notch is in the south rim at x = 0, under the hood.

## 2x2 variant: `sk1_2x2_case.py`

The cable-bay case on a whole 2x2 square, so nothing overhangs a neighbouring cell. Run
`python3 sk1_2x2_case.py .`, which writes `sk1_2x2_case_*`. Base and lid are 55.5 × 55.5 with four snaps. The
key sits in the middle of the square, 36.0 mm above the openGrid face, the same height as the 2x1 cases.

- **Base**: the board sits in the middle, held by 1.2 mm walls north and south. North of it is the bay for
  J3's plug, and south of it an empty pocket.
- **Lid**: covers the whole square, flush with the walls. The cable rises from J3 through a slot in the lid, under
  the hood. Latches on the outer north wall (x ±12..22, over the bay) and south wall (x ±6..22, over the empty
  pocket); pry notch in the south rim at x = 0, under the hood.
- **Hood**: 39.6 × 55.5 × 9.6 mm, the length of the module and the full depth of the square, with 2 mm walls
  all round. The space north of the module is where the cable turns into the module's plug. Eight pegs hold
  it to the lid. The lid's ends stay uncovered, so J1 and J2 open at each end as on every tile.
- **Cable**: about 50 mm is enough. The base's bay is 13 mm deep and has room to coil some slack, but not the whole
  200 mm cable.
- Fit order as for the cable-bay case: plug J3, drop the board in, click the lid on, plug the module and press
  it into its sockets, then press the hood on.

## Where the module numbers come from

Waveshare's "0.85inch ScreenKey Module B" download (dimension drawing and 3D model, dated 2026-07-10). It gives
the carrier as 26.01 × 35.31 and the keycap as 21.89 × 25.13. The keycap top is 24.0 above the standoff ends.

| Constant | Value | Where it came from |
|---|---|---|
| `MOD_HOLE_X` | 29.25 | hole pitch along the case, from the drawing; the 3D model agrees |
| `MOD_HOLE_Y` | 20.0 | hole pitch across the case, from the drawing; the 3D model agrees |
| `STANDOFF_AF` | 3.0 | M2 hex across flats, from the 3D model |
| `STANDOFF_L` | 8.0 | standoff length behind the carrier, from the drawing |
| `MOD_BACK_H` | 3.57 | the 9-pin socket, the tallest part on the carrier's back, from the 3D model; 1.43 mm clear of the lid |
| `SOCKET_FIT` | 0.10 | press fit on the hex's corners; raise to 0.2 if the standoffs will not go in |

`python3 sk1_case.py <outdir> <module .stp> <board .step>` also writes `sk1_case_assembly.step` (case, board and
module) and reports any overlap between them. Export the board with
`kicad-cli pcb export step --user-origin 125x111mm --subst-models`. Waveshare's model is not in the repo.

Check the socket fit on a real module before printing a batch. The geometry is no longer a guess, but your
printer's hole shrinkage is.
