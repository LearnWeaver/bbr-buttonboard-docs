# tile-mx1-1x1 openGrid case

A 1x1 openGrid case for the 25 × 25 mx1-1x1 board: 27.5 × 27.5 × 15.0 mm, plus one snap 3.4 mm deep.
`mx1_1x1_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 mx1_1x1_case.py .`

- **Lid = switch plate.** The lid is 1.5 mm thick with a 14.0 mm MX cutout over the key centre (112.5, 112.5).
  Its top is 5.0 mm above the PCB. The switch clips in, so key presses load the case.
- **Top**: flush, 15.0 mm above the openGrid face like every case (IMPLEMENTATION.md §56). The plate drops into a
  pocket 0.8 mm in from the outside and snaps in on two hooked tabs, y −8..8 on the west and east walls (the north
  and south edges carry parts as tall as the tabs). The 1.1 mm walls leave only a 0.3 mm step under the plate edge,
  so four 2.4 × 2.6 posts under the plate's corners rest 0.1 mm above the board. A pry notch mid-north lifts it out.
- **Base**: J1 and J2 hang 4.25 mm below the board (IMPLEMENTATION.md §40.2); the board sits 6.8 mm off the
  floor on a U-shaped ledge under its north, west and east edges. The south edge carries the connectors.
- **Cables**: the south wall is open below the board across nearly its full width. Both plugs go in from the south,
  under the board, and the cables leave parallel to the openGrid surface.
- **Walls are 1.1 mm**: a 25 mm board in a 28 mm cell leaves no more, and the latch grooves leave 0.5 mm of it. Print with at least 3 perimeters at 0.4 mm.
- **Assembly**: plug both cables into the board first, then drop it in and snap the lid in. Push the switch through
  into the socket last. Pull the switch before taking the lid off.
- **Print**: base floor-down, snap on the bed. The wall over the cable opening bridges about 25 mm. Lid top-down; the STL is already flipped.
- **tile-mx1rgb-1x1** fits the same case: same outline, J1/J2 0.3 mm further south, and an LED and two caps on the
  back near the key, all clear of the ledges.
- TP1–TP3 on the back are covered by the base, so program the board before casing it.
