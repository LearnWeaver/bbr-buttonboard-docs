# tile-disp1 openGrid case

A 2x1 openGrid case for the 50 × 20 disp1 board and its 0.91" display module: 55.5 × 27.5 × 15.0 mm, plus
two snaps 3.4 mm deep. `disp1_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the
snap from `../../main-module-xiao/case/mm_case.py`. Run `python3 disp1_case.py .`

- **The board goes in upside down.** Every part, J1 and J2 included, is on the board's front, and the
  display module sits over its back. So the front faces the floor and the back faces the lid.
- **Base**: the board stands 4.75 mm off the floor, clear of J1/J2 (4.25 mm), on ledges under its north
  and south edges. The south ledge stops either side of C4.
- **Cables**: J1 and J2 have their mouths at the west and east edges. Both end walls are open under the
  board, so each plug goes in from the side, as on tile-disp2.
- **Flush snap-in lid** (IMPLEMENTATION.md §56): the walls rise to 15.0, the height every case shares, and the
  lid drops into a pocket 0.8 mm in from the outside and finishes flush. Two hooked tabs on each long wall
  (x ±5..17, between the corner posts and clear of the module frame) snap into grooves; lever it out at the
  notch in the J1 end's rim.
- **Lid**: a 1.5 mm plate with a 24.8 × 8.0 mm window over the panel's active area. A frame under it
  locates the module, and two lips under the module's long edges clip it in, so the lid holds the module
  and the four wires only carry signals. Both short frame walls are notched for the wires. Four posts
  under the lid press on the board's back corners, clear of the module and the test pads.
- **Assembly**: solder the module's four wires into J3's holes. Plug both cables in and drop the board
  onto the ledges, back up. Push the module into the lid's frame, face down, until the lips click under
  its edges, then click the lid on, folding the wires under the module.
- **No header in J3.** The case leaves 4.75 mm under the board's front, so a pin header fitted in J3 from
  the front would hit the floor. Solder the wires straight into the holes, or trim the tails flush.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped.
- The back-side test pads are under the module, so program the board before casing it.

## Assumed, not measured

The module numbers are the common 0.91" 128 × 32 SSD1306 board, not a measurement of yours:

| Constant | Value | What to measure |
|---|---|---|
| `MOD_L`, `MOD_W` | 38.0 × 12.0 mm | the module's PCB |
| `MOD_PCB_T`, `GLASS_T` | 1.2, 1.4 mm | the module PCB, and the glass on top of it |
| `WIN_DX` | 0.0 mm | where the lit area's centre is, along the module, from the module's centre |

**The module must sit 2.95 mm above the board's back** (`MOD_GAP`, no longer a setting: the lid holds the
module and the lid's height is fixed, so the gap is what is left). It was assumed to be 5 mm; it came down to
fit the 15.0 top. J3 is under the module, so its four wires and their joints on the board's back must fold
flat into 2.95 mm, and into 2.15 mm under the frame's lips. Check that with a real module and wire before
printing. If the module's PCB and glass are thicker than 2.6 mm together, the gap shrinks by the difference;
the script stops below 2.5 mm. `python3 disp1_case.py <outdir> <board .step>` also writes
`disp1_case_assembly.step` and reports any overlap. Export the board with
`kicad-cli pcb export step --user-origin 125x110mm --subst-models`. The KiCad model's J3 pin header shows
as an overlap with the floor; see "No header in J3" above.
