# tile-mx9rgb openGrid case

A 3x3 openGrid case for the 60 × 79.05 mm mx9rgb board: 83.5 × 83.5 × 15.0 mm, plus nine snaps 3.4 mm deep.
Like every case, its top is at 15.0 mm and the lid sits flush in the walls (IMPLEMENTATION.md §56).
`mx9rgb_case.py` (CadQuery) builds it from the board's KiCad coordinates. It is the mx6rgb case
(`../../tile-mx6rgb/case/`) for the board with the third key row, and reuses the snap and the flush top from
`../../main-module-xiao/case/mm_case.py`. Run `python3 mx9rgb_case.py .`

- **Lid = switch plate.** The lid is 1.5 mm thick with nine 14.0 mm MX cutouts on the 19.05 mm pitch, at x
  110.95 / 130 / 149.05 and y 110.95 / 130 / 149.05. Its top is 5.0 mm above the PCB, so the switches clip in
  and key presses load the case.
- **Base**: the board rests on ledges under its west and east edges, with its top at z 10.0. That leaves
  6.8 mm under it for the hot-swap sockets, the switch centre posts and the reverse-mounted SK6812MINI-E LEDs.
  Board clearance is 0.15 mm. The board is centred in the cell.
- **Latches on the east and west walls, not north and south.** A 79.05 mm board in an 83.5 mm cell leaves the
  north and south walls only 2.07 mm thick, too thin for the latch pockets the mx6rgb case hangs there. The
  east and west walls are 11.6 mm thick, as on the mx6rgb, so the four tabs hang in pockets inside them,
  1.6 mm in from the outside, at y −8..4 and 18..30: clear of the J1/J2 slots (y −34.5..−18.5). A pry notch
  in the east wall, at y 11, lifts the lid out.
- **J1 and J2**: at the west and east ends of the electronics band along the south edge, 19.05 mm further
  south than on the mx6rgb. The case is open above them and through the end walls (IMPLEMENTATION.md §39.3),
  so the plug drops in from the end and its latch can be reached from above.
- **Assembly**: board into the base, snap the lid in, then push the switches through into the sockets. Pull
  the switches before taking the lid off.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped. Tune `PLATE_HOLE`
  (13.9–14.1) to your printer, as on the other key cases.
- **Checked**: the script fails if the base or lid touches the PCB, J1/J2 or the back-side sockets (boxes from
  the PCB's courtyards). Also checked once against a model exported from the current PCB with
  `kicad-cli pcb export step`: no overlap with the base; the lid meets only the switch models passing through
  their plate holes. `../tile-mx9rgb.step` in the repo is **stale**: its board is 62 × 84, from before the
  2026-10-20 relayout, so do not check against it.

Not printed or fitted yet, and the board has never been made (r1).
