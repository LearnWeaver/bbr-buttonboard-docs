# tile-mx4 openGrid case

A 3x2 openGrid case for the 57 × 39 mx4 board: 83.5 × 55.5 × 15.0 mm, plus six snaps 3.4 mm deep. Like every case, its top is at 15.0 mm and the lid sits flush in the walls (IMPLEMENTATION.md §56).
**It fits tile-mx4rgb too**: same outline, keys and connectors, and the RGB board's LEDs are on the back,
within the space under the board. `mx4_case.py` (CadQuery) builds it from the board's KiCad coordinates. It is
the mx3rgb case design with the WASD key layout, and it reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 mx4_case.py .`

- **Lid = switch plate.** The lid is 1.5 mm thick with four 14.0 mm MX cutouts: W at (128.5, 110), and A, S, D
  at y 129.05, x 109.45 / 128.5 / 147.55, on a 19.05 mm pitch. Its top is 5.0 mm above the PCB. The switches
  clip in, so key presses load the case. It drops into a pocket 0.8 mm in from the outside and finishes flush
  with the walls at z 15.0. Three hooked tabs snap into grooves in the long walls: north x −12..12, south
  x −15..−4 and 4..15, clear of mx4rgb's per-key caps. A pry notch in the west end, at y −12, lifts it out.
- **Base**: the board rests on ledges under its two short ends, with its top at z 10.0 so the plate sits at
  the MX 5.0 mm. That leaves 6.8 mm under the keys for the sockets, the switch centre posts and mx4rgb's
  reverse-mounted SK6812MINI-E. Board clearance is 0.15 mm.
- **J1 and J2**: they sit in the corners beside W. The case is open above them and through the end walls
  (IMPLEMENTATION.md §39.3), so the plug drops in from the end and its latch can be reached from above.
- **Walls are thick**: the board leaves 13 mm of the cell at each end and 8 mm along each side.
- **Assembly**: board into the base, snap the lid in, then push the switches through into the sockets.
  Pull the switches before taking the lid off.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped. Tune `PLATE_HOLE` (13.9–14.1)
  once the mx1rgb case shows how your printer holds a switch.
- The back-side UPDI test pads are covered by the base, so program the board before casing it.
