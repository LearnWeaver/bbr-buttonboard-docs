# Low-profile cases

The parts on the docs site have been printed and tested (Daniel, 2026-11-24); no measurements were
recorded, so the "assumed" tables below keep the modelled values. Started as a proof of concept: it answers one question, how thin the range can get
without the openGrid board and still be modular. `lowpro.py` builds everything; run it under CadQuery like
the case scripts (`python lowpro.py .`), then `render.py . top|under|deck|pads|pads_parts` and `height_compare.py out.png`
for the pictures.

## What it is

| | Today | Low profile |
|---|---|---|
| Under the cases | openGrid board, 6.8 mm | nothing, 0.8 mm pads, or a 1.2 mm deck |
| Case top above what it sits on | 15.0 | 10.0 |
| Desk to the switch plate | 21.8 | **10.0** (keys) / **10.8** (pads) / **11.2** (deck) |
| Footprint | cells of 28 mm, less 0.5 | the same |

The cases are the existing ones. `lowpro.py` runs each case script with three numbers changed (top 15.0 → 10.0,
floor 1.6 → 1.0 or 1.2, room under an MX board 2.6 → 2.4) and the snaps left off, so the lids, latches, plate
holes and cable slots are the ones already printed and proven. Kept on the 28 mm grid on purpose: layouts
from the planner carry over, and the lid of an MX case is the same part as today's.

What replaces the board is a **link pocket**: a dovetail 3.0 mm deep in the underside, at the middle of
every cell edge on a case's perimeter where the wall is solid (the script tests each one). Three ways to use it:

- **Link keys.** A bow-tie 6.4 × 4.5 × 2.8 mm presses in from below across two facing pockets. No base
  at all; the panel is exactly as thick as a case. Rearranging is pulling keys.
- **Padded keys and feet.** The same key on a 0.8 mm pad, 12 × 15 mm, that reaches 7.5 mm under both cases,
  so a case hanging off its neighbour bears on the pad and does not lever the key out. A pad lifts the cases,
  so every other pocket takes a **foot** (half a key on a pad) and the panel stands level 0.8 mm off the desk.
  The Starter Bundle takes 7 padded keys and 16 feet (`lp_starter_pads_underside.png`). The main module, with
  both pockets at its west end, still tips 0.8 mm at its east end; arc4 can rock about its long axis
  Print pad down, no supports (`lp_link_key_padded.stl`, `lp_link_foot.stl`; IMPLEMENTATION.md §85).
- **A deck.** A 1.2 mm plate cut to one layout with half a key standing on it under every pocket. One
  print, stiff, and the place to put feet, a tilt or a wrist edge later. Cases still lift off and go back, but a
  case only sits flat where it has a pocket over every stud, so another case of the same size may not fit
  (enc1 has 6 pockets, arc4 2). The docs site's layout planner makes a deck for any layout (IMPLEMENTATION.md §84).

## The demo

The Starter Bundle on a 4 × 4 grid, 112 × 112 mm: main module, two mx1rgb 1x1, two mx3rgb (one turned),
one mx4rgb. 30 pockets, 7 keys between cases. The renders here still show the full-length mx3rgb.

## What the model shows up

- **mx1rgb 1x1 stands 2.4 mm proud** (12.36). Its J1/J2 hang under the board, and 4.25 mm of connector
  sets its height, not the switch. Level with the rest needs the connectors on the front or the edge:
  a board change.
- **The main module takes only two pockets** (north and south of its west cell). USB fills the west end,
  J2/J3 the east cell's walls, and the east wall is 1.75 mm. In the demo that is one key holding it. A deck
  holds it by both.
- **Room under an MX board is 2.4 mm**, and the board models reach 2.14 below it: 0.26 spare over a
  1.0 mm floor. Checked against the mx3rgb, mx4rgb, mx1-1x1 and main-module STEPs: no overlap beyond the
  switches in their plate holes and a board on its ledge, as for today's cases.
- **lp_mx3rgb is 6 mm short at each end** (2026-11-24), 71.5 × 27.5 on its three cells, so each end leaves
  6.25 mm to the grid line, the case's full width, to wrap the bus lead into outside the case. 8 mm was asked
  for; 6.0 is the most there is: past the board each end was a solid block 8.6 mm long, and a 2.6 mm end wall
  (the side walls' thickness) has to stay for the board's end stop, the lid's seat and the pry notch. The end
  is now 2.75 mm past the board edge where J1/J2 open, so the plug stands out of it with its latch open from
  above and from the end. The ends lose their link pockets: they are off the grid line, so no key could reach
  them (`lowpro.Case` skips a wall that is not on its grid line), which leaves six on the long walls; in the
  Starter Bundle that is one key fewer (7), the mx3rgb's east end against the turned mx3rgb. The lid is the
  same design, 12 mm shorter. It replaces the cable wells inside the ends tried first (6ae3c1f), which
  had nothing left to open. It is `END_TRIM` in `mx3rgb_case.py`, set per case in `lowpro.py`; the openGrid
  and panel mx3rgb cases are as they were (the script refuses `END_TRIM` with `--panel`, whose screws sit at
  the full length's ends). Printed and tested (Daniel, 2026-11-24).
- **Keys join at the bottom only**, with 0.5 mm between cases, so a keyed panel can flex about 3° at a
  joint when lifted by one end. Padded keys spread that over their pads; the deck does not flex.
- **Nothing holds a key but its fit** (0.10 mm a side, `LINK_CLR`). Tune it on a print.
- **Outside edges show their unused pockets** as 4 mm notches at the foot of the wall.
- Modelled for the v1 boards as built: disp2, mx6rgb, mx9rgb, enc1, disp1, arc4, screenkey1 and stick1
  (`lp_disp2.py`, `lp_mx6rgb.py`, `lp_mx9rgb.py`, `lp_enc1.py`, `lp_disp1.py`, `lp_arc4.py`, `lp_screenkey.py`,
  `lp_stick1.py`, below).
  Their height is the part, not the board, so each needs its own look.

## disp2: `lp_disp2.py`

A low-profile case for the **v1 disp2 board as built** (50 × 40, panel on the front, everything else on the
back, J1/J2 included). Native to the low-profile numbers, like `hardware/v2/tile-mx1rgb-v2/case`, because the
openGrid disp2 case cannot get there by substitution: its stack is 11.85 at a 10.0 top. Board and panel facts
come from `../tile-disp2/case/disp2_case.py` (unchanged), connector and part heights from the board's
`.kicad_pcb` and STEP.

    python lp_disp2.py . [--render]     # base + lid STEP/STL, fit check; --render: the four PNGs

- **Footprint 2 × 2, 55.5 × 55.5 × 10.0.** The board is 50 mm one way and 40 the other; one cell is 27.5,
  so both directions need two. Same as the openGrid disp2 case, so planner layouts carry over. All 8 link
  pockets go in (the end walls are 2.55, just over the 2.5 a pocket needs), so it keys to any low-profile
  case on any side; `lp_disp2_with_mx4rgb.png` shows it under lp_mx4rgb with two keys.
- **How it reaches 10.0.** J1/J2 hang 4.33 under the board, twice anything else there (U5, 2.25). Each one
  sits in a **window through the floor**, open to its end wall, and stands 0.22 off the desk; the rest of
  the back keeps the 1.0 floor under it with 1.30 to spare. The window is also the way to the plug's latch,
  which faces the desk on a back-mounted GH. Then the **lid is a frame**: 1.5 thick over the walls and the
  bare board, 0.85 over the glass, where a pocket in its underside (the glass outline plus the flex fold,
  0.3 round) lands on the glass border.
- **Stack**, desk up: J1/J2 0.22–4.55, PCB 4.55–6.15, tape 0.5, glass 6.65–9.15, lid lip 9.15–10.0. The
  glass is **0.85 below the lid surface**; the window is the active area plus 0.3, so the lid bears on
  2.5 mm or more of border all round and never on the active area. Ledges under the north and south edges
  (the south one stops either side of the §27 pads); latches and pry notch as the openGrid case.
- **Fit check** (the script runs it): every back part's courtyard × its depth from the board STEP, J1/J2
  with a cable-exit corridor out past the case edge, the PCB, tape, panel, the flex fold west of the glass,
  and the active area's line of sight, each intersected with base and lid; then every solid of the board
  STEP the same way. **No overlap.** Margins: connector to desk 0.22, plug to the side of its opening 1.22,
  flex fold to the lid pocket 0.61 above / 0.30 west, flex to the west wall 0.80, board top to the lid
  outside the glass 2.35, latch tab outboard of the board 0.48.
- **Cables leave at desk level, through the west and east ends** (the opening is 13.2 wide, from the desk
  to the board's underside, centred on the case centre line, which is the line *between* its two rows).
  Nothing above can take them, because the board fills the case to 0.2 of the end walls. So **a case
  keyed directly west or east of a used connector blocks the lead**: the gap is 0.5 mm. Join a disp2 to
  its neighbours on its north and south edges, and leave the cell beyond each used end open (a lead that
  ends the chain needs only one). A `2x1_disp2` link block standing along that end takes the lead through a desk-level window and keys to
  the disp2 on the same edge (Link blocks, below).
- **Print**: base floor-down; lid top-down (the STL is flipped), so the 0.85 lip is the first layers.
- **Assembly**: as the openGrid case. Glue the panel and solder its flex, program the board (the §27 pads
  are covered), plug both leads in, drop the board onto the ledges with the plugs through the windows,
  snap the lid on.

### Assumed, not measured: measure these before printing

| What | Value | Why it matters here |
|---|---|---|
| `PANEL_T`, glass + backlight | 2.5 (disp2_case.py; LCD1's 3D model says 2.51) | The ledges are printed for the assumed stack. Thicker and the lid will not seat (the board cannot go down); thinner and the lid floats above the glass instead of clamping it. Rebuild with the measured value: the ledges come down by the difference, and the connectors have **only 0.22 mm** to give, so the script refuses a stack over 3.22 at a 0.85 lip (3.47 with `LIP_T` at 0.6) |
| `TAPE_T`, tape or glue under the glass, over the folded flex | 0.5 | Same: measure glass top to board top on a glued-up board and set the sum to that |
| GH plug outside the receptacle | not modelled past the body; the corridor is the body's own section | The plug and the lead's bend need room beyond the case edge; see the cable note above |
| `LINK_CLR` | 0.10 | As every low-profile case: tune on a print |

Printed and tested (Daniel, 2026-11-24).

## mx6rgb: `lp_mx6rgb.py`

The **v1 mx6rgb as built** (60 × 60, six keys, J1/J2 on the front) in a low-profile case. The case is lowpro.py's
own, `lowpro.Case("mx6rgb")`: the openGrid case script at the three low-profile numbers, exactly as lp_mx3rgb
and lp_mx4rgb are made, so the plate, plate holes, latches, pry notch and J1/J2 slots are the proven ones. What
the file adds is the check against the board's `.kicad_pcb` and STEP, and the lead into its link block.

    python lp_mx6rgb.py . [--render]     # base + lid STEP/STL, fit and lead checks (about 3 min); --render: PNGs

- **3 × 3, 83.5 × 83.5 × 10.0.** The board is 60 square, so it needs three cells each way. 3 × 2 would need a
  41 mm board (V2_BOARDS.md §5.2), which is a v2 question. Nothing hangs under the board: the deepest part
  under it is a hot-swap socket, 0.27 above the 1.0 floor. So it reaches 10.0 with no floor windows.
- **Plate and keys as lp_mx3rgb / lp_mx4rgb**: PCB 3.4–5.0, plate 8.5–10.0, top 5.0 above the PCB. A panel of
  low-profile key tiles reads level.
- **LEDs.** The six SK6812MINI-E are reverse-mounted on the back and shine up through the PCB into the
  switch. The board has no WS2812; the openGrid case does nothing for the light but the plate hole. A
  3.2 × 2.8 column over each LED, from the PCB to above the top, clears base and lid: nothing shades it.
- **12 link pockets of 12**: the walls are 11.6 thick, and the J1/J2 slots start at z 4.4, above the pockets.
- **Fit check** (the script runs it): every footprint's courtyard × its depth or height from the STEP, each
  switch as a 13.9 body through its plate hole, the six light columns, and J1/J2 with a plug-and-lead
  corridor out past the case edge. **No overlap.** The board STEP's own solids overlap only the lid, and only
  the six switch models in their plate holes (10.7 + 0.7 mm³ each: the clips and the top housing on the
  plate), as for today's cases.
- **Leads leave through the west and east ends, high**: J1/J2 are on the front, body z 5.0–9.24 under an open
  slot in the lid, centred 17.0 south of the case centre. That is **3.0 south of the line between the middle
  and south rows**, so no 1x1 and neither of the other 2x1 blocks meets it. `2x1_mid` does: a 2x1 standing
  along that end over those two rows, with a 13.2-wide high window (z 3.9–8.5) centred on its long side.
  Modelled in the preview layout (mx4rgb, a straight 1x1, `2x1_mid`, mx6rgb; 6 keys, no overlaps): J1's body
  and plug (`PLUG_OUT` 5.0 past the mouth), then a 3.3 mm lead at z 5.0–8.3 into the block. **No overlap**,
  1.95 to spare beside the lead in the window, 0.2 under the lid.
- **Print** as the other key cases: base floor-down, lid top-down (STL flipped). No supports: the pocket roofs
  are the usual bridges, and the J slots are open to the top.

Measure before printing: `PLUG_OUT` (the GH plug's tail past its mouth, assumed 5.0), the 3.3 mm lead,
`LINK_CLR`. Printed and tested (Daniel, 2026-11-24).

## mx9rgb, on the desk and in a panel: `lp_mx9rgb.py`

The **v1 mx9rgb as built** (60 × 79.05, nine keys, J1/J2 on the front). One script, three variants. The case
is lowpro.py's own, `lowpro.Case("mx9rgb")`: mx9rgb is now in its `TILES`, and the case is built at the
low-profile numbers exactly as lp_mx3rgb, lp_mx4rgb and lp_mx6rgb are. The panel variants add IMPLEMENTATION.md
§80's flange to that same case with `mm_case.py`'s shared helpers, as `mx3rgb_case.py --panel / --rear` do.

    python lp_mx9rgb.py . [--render]                  # desk case; the board STEP check takes several minutes
    python lp_mx9rgb.py . --panel [--quick] [--render]
    python lp_mx9rgb.py . --rear [--panel-t=3.0] [--quick] [--render]

- **3 × 3, 83.5 × 83.5 × 10.0.** The board is 60 × 79.05, so three cells each way. It fills the case to within
  2.07 mm of the north and south walls.
- **Plate and keys as the other key tiles**: PCB 3.4–5.0, plate 8.5–10.0. Nothing hangs under the board; the
  deepest part is a hot-swap socket, 0.27 above the floor.
- **LEDs**: nine reverse-mounted SK6812MINI-E. A 3.2 × 2.8 light column over each clears base and lid.
- **Link pockets: 6 of 12**, three on each of the west and east walls. The north and south walls are 2.07
  thick and a pocket needs 2.5, so neither takes one. The board, not the case, decides that. Key it to its
  neighbours on its ends; a deck holds it on all sides.
- **Fit check**: every footprint's courtyard × STEP depth or height, the switches as 13.9 bodies through the
  plate, the light columns, and J1/J2 with plug-and-lead corridors out past the ends. **No overlap.** The
  board STEP's own solids touch only the lid, and only the nine switch models in their plate holes.
- **Leads**: J1/J2 leave through the west and east ends, high (body z 5.0–9.24 under open slots). Each is
  centred **1.48 off the south row's centre**, so a `straight` 1x1 link block (or `2x1_mx` at that cell)
  takes it directly. Modelled in the desk preview (a straight block at each end of the south row, mx4rgb
  above the east one; 5 keys): plug 5.0 past the mouth, a 3.3 mm lead at z 5.0–8.3 into each block's
  window. **No overlap**: 1.37 to spare beside the lead, 0.2 under the block's lid.

### `--panel`: front-mounted in a console panel

- **Flange**: two 6.0 × 2.5 strips on the north and south walls, the ones without cable slots. The top is
  flush with the plate at 10.0, so the flange sits on the panel's front face at 7.5 and the case hangs
  **7.5 behind the face** (the openGrid `--panel` hangs 12.5). The plate stands 2.5 proud of the panel, as
  on the openGrid panel cases. Four countersunk M3 at (±36, ±44.75), as mx3rgb.
- **Aperture DXF** (`lp_mx9rgb_panel_aperture.dxf`): an 84.0 × 84.0 opening, R2.25 corners (the case + 0.25 a side).
  At each end an ear 7.0 long × 13.30 wide, at y −33.17..−19.88: over the J1/J2 slots, south of centre.
  98.0 overall. Four 2.5 pilots.
  - The script checks that the case outline lies wholly inside the aperture (0 mm²).
  - The flange covers the aperture's north and south edges by 5.75.
  - What it leaves open (227 mm²) is the 0.25 gap at each end and the ears, by design as on mx3rgb.
- **Slots and panel thickness**: the cable slots start at z 4.4, under the panel face at 7.5. So a panel
  of any thickness sits across them, and the ears let the plugs and leads through, as §80 says of mx3rgb.
  Checked with 3, 6 and 12 mm panels: no overlap with the case or with the plug-and-lead corridors.

### `--rear`: mounted from behind, plate flush with the panel's face

Built too, and it makes more sense here than on the openGrid case, because the case is shallow. The flange
sits `PANEL_T` lower, on the panel's back face, so the plate finishes flush with the front.
- **The trade-offs are §80's.** The part is cut for one panel thickness (`--panel-t`, default 3.0). The
  screws go blind into the panel's back: heads on the back, no pilots in the DXF. The aperture adds a
  4 × 10 scallop at the east-wall pry notch.
- **The low profile caps the panel at 6.5 mm**: the flange (2.5) has to stay above the 1.0 floor. The
  openGrid case would take about 11.
- **Depth**: at 3.0 the case reaches 10.0 behind the panel's front face, 7.0 behind its back. The ears are
  needed as before, and the 3 mm check passes.

**Print**: the desk base floor-down, no supports. A panel base floor-down needs **supports under the two flange
strips**: each is a 6.0 mm shelf off the outside of the wall, at 7.5 (`--panel`) or 4.5 (`--rear`), and a
45° gusset under it would land where the panel goes. Upside down is worse, because the floor becomes an
80 mm bridge. The same holds for the openGrid panel cases, whose README does not say. Lid top-down, as every case.

Measure before printing: `PLUG_OUT` (5.0), the 3.3 mm lead, `LINK_CLR`, the panel's real thickness for `--rear`.
The desk case is printed and tested (Daniel, 2026-11-24); the panel variants are not recorded as printed.

## Link blocks: `lp_link_block.py`

Blank cells with no board: they key the cases round them together and carry bus leads. A 1x1 and three 2x1s, at
the system top of 10.0 (lp_mx1rgb_1x1's 12.36 is its board's fault, not the footprint's). Walls 2.6 (the least
a pocket takes), floor 1.0, the shared flush lid with nothing through it, and **a link pocket on every cell
edge** (4 on the 1x1, 6 on the 2x1). One script builds every variant.

    python lp_link_block.py . [--render]    # every variant, STEP/STL, the disp2 lead-path check; --render: PNGs

| Variant | Size | Windows | Latches | Pry notch | Goes |
|---|---|---|---|---|---|
| `straight` | 27.5 × 27.5 | W, E (high) | N, S | W, at +9 | a blank cell in a run of MX leads |
| `corner` | 27.5 × 27.5 | W, N (high) | S, E | W, at +9 | where such a run turns |
| `2x1_disp2` | 27.5 × 55.5 | **E desk-level, centred**; W at both cell centres, N, S (high) | W, E, −8..8 | N, at +9 | along a disp2's end, desk window facing it |
| `2x1_mx` | 27.5 × 55.5 | E and W at both cell centres, N, S (high) | W, E, −8..8 | N, at +9 | a two-cell blank in a run of MX leads |
| `2x1_mid` | 27.5 × 55.5 | E and W **wide** (13.2, high), centred; N, S (high) | W, E, at ±12..22 | N, at +9 | along an mx6rgb's end, covering its middle and south rows (`lp_mx6rgb.py`) |

Turn a block in the grid for the other orientations: `2x1_disp2` turned 180° stands along a disp2's east end.

- **Floor hole 11.0 round**, centred: cable-1x1's drop hole, which passes a GH plug (about 8.0 × 4.3,
  9.1 across the diagonal) and its lead coming up through a desk or a panel. With a deck under the
  layout, the deck needs the same hole. `Layout.deck()` does not cut one; the planner's deck does, under a `drop` tile.
- **High windows 9.0 × 4.6**, z 3.9 to the lid's underside at 8.5, centred on a cell edge. 9.0 is cable-1x1's
  channel. The bottom is 3.9 because the link pocket underneath needs solid wall up to 3.8. The rim above
  stays whole, so the top reads as a closed square. That also means one end of a lead has to be threaded
  through; 4.6 passes the plug with 0.3 to spare.
- **The desk window (2x1_disp2) 13.2 wide, desk to 4.8**, centred on the long side: the disp2's own end
  opening (13.2, desk to 4.50) facing it across the 0.5 gap. It reaches 1.0 into the floor so the lead can
  step up onto it. On a 2x1 the middle of a long side is a cell edge, and its pockets are at ±14, so both
  fit: the window stops 3.4 short of the pockets' solid zone. Both keys on the shared edge go in.
- **The disp2 lead, checked.** The script builds the preview layout (mx4rgb, 2x1_disp2, disp2), then models
  the disp2's J1 lead: the receptacle's own section from lp_disp2's corridor (±5.38, z 0.22–4.47), from the
  back of the GH body to inside the 2x1, then a 3.3 mm bundle across the 2x1's floor, up to its north-west
  window and into mx4rgb's J2 slot (z 5.1–8.4, over mx4rgb's board). Intersected with every base and lid:
  **no overlap**. The plug section clears the desk window by 1.22 a side and 0.33 above. As a control, the
  same check with `2x1_mx` in the disp2's place finds the 2x1's wall in the way (126 mm³).
- **Hands with leads in.** The pry notch is on a short end at +9, off the end window; the latches are on the
  long walls, above the desk window, so nothing about a lead in place covers them.
- **Print without supports**: base floor-down. A high window's only roof is the 0.8 mm rim (a 9 mm bridge);
  the desk window's roof is the full wall over 13.2 mm; pocket roofs are the same bridges as every
  low-profile case. Lid top-down, flat, tabs up (STL flipped).
- **Where the leads arrive** (offset along the shared edge from the cell centre, and height):

  | Neighbour | Lead arrives | High window ±4.5, z 3.9–8.5 |
  |---|---|---|
  | lp_mx3rgb | connector centre +1.0, out of a slot open from z 4.7 | lines up |
  | v2 mx1rgb | 0, from z 4.7 | lines up |
  | lp_main | J2/J3 centre −2.25, body z 2.8–7.05 | lines up, the lead drops ~1 mm in |
  | lp_mx4rgb | centre −4.5 from its north row (connector −10.5..+1.5), from z 4.7 | half: the lead jogs ~4 mm in mx4rgb's slot (as modelled above) |
  | lp_mx1rgb_1x1 | ±6.22, desk level (body z 1.5–5.75) | barely: off to one side and below |
  | lp_disp2 | **on the cell edge** (±5.4 round it), desk level z 0.22–4.47 | no: use `2x1_disp2`'s desk window |
  | lp_mx6rgb | 3.0 south of the line between its middle and south rows, from z 5.0 | no: use `2x1_mid` |
  | lp_mx9rgb | +1.48 from its south row's centre, from z 5.0 | lines up (`straight`, or `2x1_mx` at that cell) |

  A 1x1 cannot take a disp2's lead: on any 1x1 it arrives at the corner, behind the end of the
  neighbouring wall. That is what `2x1_disp2` is for.

Assumed, not measured: the GH plug (8.0 × 4.3, from cable-1x1's brief; the splitter case allows 10.4 wide
for a plug with its lead, which would **not** pass a 9.0 window, though it would pass the 13.2 desk window),
the 3.3 mm lead bundle, and `LINK_CLR`. Printed and tested (Daniel, 2026-11-24).

## Cable rails: `lp_rail.py`

A concept for the leads that link blocks do not reach: the ones that **leave a case end on the panel's edge** and
loop round outside it. A rail is a raceway that stands along that edge, half a cell wide (13.5) and level with the
cases at 10.0. It takes a lead under a roof to any other case end on the perimeter, corners included. A link
block still does the job inside a panel; a rail costs 14 mm of border where a block costs a 28 mm cell.

    python lp_rail.py . [--render]     # the demo's rails, a stock 3-cell rail, the deck, lead checks; --render: PNGs

![rails](lp_rail_preview.png)

- **Section**, outward from the case: a 4.0 slot along the case wall (3.5 of rail and the 0.5 gap), then a 10 mm
  roof, 1.5 thick, and a 1.6 outside wall. The floor is 1.0 and stops 4.0 short of the inner edge. The channel is
  11.9 × 7.5: two 3.3 leads side by side on the floor, with room to turn out of a case.
- **The side facing the case is open.** A lead comes out of a case end at whatever offset and height its
  connector has, and there is nothing to line up with. The link blocks need a variant per connector position
  (`2x1_disp2`, `2x1_mid`, the unbuilt `straight-s4` and desk-window 1x1); a rail needs none.
- **No lid, nothing to thread.** Plug the lead into the case (the MX, enc1 and arc4 end slots are open to the
  top), press it down through the slot, run it, bring it up into the other case. `lp_rail_part.png` is the part
  from the case side.
- **It joins like a case.** Where the case beside it has a link pocket, the rail has a boss (9.0 × 2.6 × 3.8)
  with a pocket of its own facing it, so a link key, a padded key or a deck stud holds both. Every high lead
  leaves its case above 3.8 (MX from 4.7, enc1 and arc4 from 3.85), over the boss.
- **Where the case has no pocket, the rail has no boss.** That is every place a plug sits at desk level by the
  edge: disp1's ends, the main module's J2/J3, mx1rgb 1x1's thin walls. A disp2's desk opening is between two
  cells, clear of both bosses, and its plug tail lies on the desk where the floor stops short. So a rail is
  made for one edge of one layout, as a deck is. `bosses="all"` makes a stock part; the control below shows
  what it costs.
- **Corners.** One rail runs on half a cell past the corner and is capped. The other stops at the case edge
  with its end open, facing the first one's open side. The lead turns inside.
- **With a deck**: the deck grows the half-cell strip under each rail and a stud under each boss
  (`deck()` in the script; one piece, 112 × 126 for the demo). The planner's deck does not know rails yet.
- **Print standing on the outside wall.** Floor, roof, caps and bosses are then vertical walls (a boss's
  underside is a 45° ramp): no supports, the outside face on the bed. The STLs are turned that way. A 7-cell
  rail is 195.5 long.

**The demo** (`lp_rail_leads.png`): main module and a blank block, mx3rgb, mx4rgb on 3 × 4 cells; rails north,
east (4 cells, open into the north one at the corner) and west (rows 1–3 only: row 0's west end is the USB).
9 keys hold the rails. Two leads as 3.3 mm boxes at z 4.8–8.1:

| Lead | Route |
|---|---|
| A | main J2 (north wall, plug at z 2.8–7.1) → north rail → round the corner → east rail → mx3rgb J2 |
| B | mx3rgb J1 → west rail → mx4rgb J1 |

Against every base, lid and rail: **no overlap**. Controls: lead B leaving mx3rgb at desk level finds the rail's
boss (22.5 mm³) and mx3rgb's own wall; stock rails with a boss in every cell find the main module's J2 plug in
the north rail's boss (4.1 mm³), which is why the bosses follow the pockets.

Open, and not decided:

- **The roof is fixed.** A lead is pressed in through a 4 mm slot, which shows as a line along the cases. A
  snap-on roof would close it but needs a second wall to sit on, and that wall is the window problem again.
- **Half a cell is a choice** (`RAIL_W`). It keeps a railed panel on a 14 mm half-grid. The least is about 10.6
  (a 9.0 channel, cable-1x1's, and the wall).
- **A rail blocks whatever else is on that edge**: the main module's USB end, arc4's button leads.
- Not modelled: a rail between two groups of cases (both sides open), a way out of a rail for a lead leaving the
  panel (today: an `open` end), and the plug paths of disp1, disp2 and mx1rgb 1x1 against a rail.

Assumed, not measured: the 3.3 lead, the GH plug (8.0 × 4.3, 5.0 past its mouth), `LINK_CLR`. Nothing printed.

### Trays fused into the deck (what the planner makes)

The rail is one way; the other, which the planner's deck now offers, is the tray **as part of the deck**
(IMPLEMENTATION.md §86). `tray_deck(lay, "NEW")` in `lp_rail.py`: the deck grows 14.0 on each tray side, with a
1.6 wall level with the cases and a lip whose underside is 45° (from 3.6 over the deck at the wall to the top 6.0
past the grid edge), so it prints flat with the deck. Leads lie on the deck under the lip. No bosses or keys: the
deck holds it. The tray is cut away 16.0 wide in front of the main module's USB; its ends are open.

![tray deck](lp_tray_deck_preview.png)

`lp_tray_deck_leads.png` is the same demo with the lids off: leads A and B, and the USB plug through its gap.
**No overlap** with any case or the deck; without the gap the USB plug finds the tray (223 mm³), and a lead run
along the tray at slot height instead of on the deck finds the lip (165 mm³).

## Labelled lids: `lp_label_lid.py`

Words beside each key for the operator, inlaid flush in the lid's top, for a two-colour print. The lid is the
case's own (`lowpro.Case(name).lid`), so the switches clip in as before and nothing changes height.

    python lp_label_lid.py <outdir> mx3rgb INTAKE SHOOT CLIMB [--render]
    # one label per key in the case's KEYS order (mx4rgb: W, A, S, D; mx6rgb, mx9rgb row by row from the
    # north-west); - for none

![mx3rgb labelled](lp_mx3rgb_lid_labelled.png)

- **Two STLs that fill each other**: `lp_<case>_lid_labelled.stl` (the lid with the letters cut 0.6 mm into its
  top) and `lp_<case>_lid_text.stl` (the letters). The script checks that together they are exactly the plain lid.
  Both are flipped top-down like every lid STL, so the letters are the first three layers on the bed and the colour
  changes stop after 0.6 mm. In Bambu Studio load both at once, answer yes to "load as one object with multiple
  parts", and give the text part the second filament.
- **Where a label goes**: against its key, on the first side (south, north, west, east) with no key next to it and
  no hole or slot under the text. The keycap hides the plate under it, so a label starts 0.6 past the cap's 18 mm
  edge. Bold Arial, as large as fits up to 4.0 mm letters, within one key pitch (18 mm) under a key or the margin
  beside it. Below 2.5 mm the strokes get thinner than a nozzle, so the script refuses.
- **What each case gets**, from the runs:

  | Case | Labels |
  |---|---|
  | mx3rgb | all three under their keys, 3.6 mm letters (about 7 characters each) |
  | mx4rgb | W above, A S D below, 4.0 mm |
  | mx6rgb | top row above, 3.3–3.8 mm. Bottom row: the middle one below, but the outer two have the J1/J2 slots under that strip, so they go beside the keys at about 2.7 mm (`lp_mx6rgb_lid_labelled.png`) |
  | mx9rgb | **refused**: 2.1 mm of lid above the top row (the board fills the case) and keys all round the middle. Label it on keycaps |

Not done: nothing printed; the font is whatever the system calls Arial; not in the planner.

## A cover over the panel: `lp_cover.py`

One plate over a whole panel, cases and trays together, held by pegs that drop into holes in the tray tops
(IMPLEMENTATION.md §88). The planner makes it with the deck.

    python lp_cover.py <outdir> [--render]    # lp_rail's demo, covered: STEP/STL and the checks

![cover](lp_cover_preview.png)

- **1.5 mm, on the case tops at 10.0**, out to the deck's edge, so it also closes the trays' open 6 mm.
- **Open where something comes through**: a 19.5 square round every key, which merge into one opening per group
  (an 18.0 keycap, 0.75 a side; a pressed keycap reaches 0.3 below the case top, so it has to go into the cover);
  every hole through a lid's top, read off the lid and grown 0.75 (a display's window, the encoder's opening, the main
  module's light and CFG holes), with a 17 mm round one for enc1's knob and arc4's window, which is open to its edge;
  and a case taller than 10.0 (mx1rgb 1x1, disp1) its own outline, standing through.
- **Pegs** 3.2 round, 2.5 long, over the trays' wall faces, at the first, last and every third cell of each tray side,
  none in a USB gap; the deck gets a 3.3 hole, 3.0 deep, under each: a press fit, as a printed hole comes out under size (2.8 pegs
  printed loose; 3.2 printed a good tight fit, 2026-11-23). Trays on two sides at least.
- **Checked** on the demo: the cover touches no case and the deck only at its holes' rims; keycaps swept from rest to
  fully down clear it (control: a 16.0 opening per key, round the switch, lets the caps hit it, 723 mm³); the light
  and CFG holes are open. The planner's cover and holed deck match this script's to 0.2 % and 0.05 %.
- **Print** top-down (the STL is turned so): flat, top on the bed, pegs up. No supports.

Not done: nothing printed; the peg fit (0.25 a side) is untuned; labels are not on it yet.

## If the boards were redrawn for these cases

Suggestions only; no layout has been done. `board_envelopes.py` draws today's outlines beside the suggested
ones (`lp_board_outlines.png`) and writes a STEP (PCB slab, connector and switch blocks) and an Edge.Cuts DXF
for each suggested board. It checks that every socket and connector is on the board and that no connector
sits under a switch body. It does not check that the MCU, transceiver and LEDs still fit.

1. **No bus connector under a board.** A JST GH is 4.25 mm tall; under the board it sets the case height
   (mx1rgb 1x1: 12.36 against 10.0; disp2 has the same arrangement). A 25 mm board has no room for two on
   the front beside a switch, so a level single key is a 2 x 1 board (38 x 22), as tile-mx1rgb already is.
2. **One board outline per footprint.** 22 mm deep for one row, 41 for two; long = cells x 28 - 18, which
   leaves 8.6 mm of plug room inside the case at each end (what mx3rgb has today). mx4rgb and mx6rgb then
   share one 66 x 41 outline and one case base; only the plate differs.
3. **mx6rgb on 3 x 2 cells, not 3 x 3.** Its 60 x 60 board spends a 20 mm strip on the MCU and connectors.
   mx3rgb already puts both chips between the switches, so six keys on 66 x 41 looks possible: a third
   off its footprint. This is the one that needs a layout to confirm.
4. **Bus connectors at one place on the grid.** Today they sit 1.0, 9.5, -17 and 0 mm from a cell's centre
   line depending on the board. On a cell centre line, mouth 8.6 mm in from the case edge, every case gets
   the same opening and neighbours' connectors face each other: one short lead, or later a rigid bridge
   under a cover.
5. **At least 2.6 mm of case wall on every edge**, which is what a link pocket needs. mx1rgb 1x1 leaves
   1.1 and the main module's east end 1.75. The main module's J2/J3 also sit 2.25 mm off its cell's centre.
6. **Keep-outs every case can rely on**: a 1.5 mm strip under both short ends for the ledges, and four
   corner lands on the front for lid posts.

Lower than 10.0 is not a board-outline question. The 10.0 is 1.0 floor + 2.4 under the board + 1.6 PCB +
5.0 from PCB to plate, and the 5.0 is the MX switch. A 1.2 mm PCB gives back 0.4. A low-profile switch
family would give back far more, as a separate product.

The detailed brief for a v2 board range is in `V2_BOARDS.md`.

## enc1: `lp_enc1.py`

A low-profile case for the **v1 enc1 board as built** (44 × 20, one EC11E with push switch at the centre,
J1/J2 on the front at the west and east ends, mouths out). Native to the low-profile numbers, as lp_disp2 is;
the openGrid enc1 case cannot get there by substitution, because it stands the board on a 3.25 ledge over a 1.6
floor. Board facts from `../tile-enc1/tile-enc1.kicad_pcb` and its STEP. This replaces "Not modelled: enc1"
above.

    python lp_enc1.py . [--render]       # base + lid STEP/STL, fit check, lead path, controls; --render: PNGs
    python lp_enc1.py . --body 6.5       # the same checks for another encoder body height, nothing written

- **Footprint 2 × 1, 55.5 × 27.5 × 10.0**, the openGrid enc1 case's footprint, so planner layouts carry over.
  **All 6 link pockets go in** (both long sides at both cells, both ends), so it keys on any side.
- **The encoder stands up through the lid and the lid touches none of it** (Daniel, 2026-11-20). The lid has a
  **13.6 × 12.7 rectangular opening, R1 corners, centred on the shaft**: the body's widest section above 1.5 over
  the board in the board STEP (12.3 × 11.7: the frame is ±6.0 × ±5.85, with a bump to x −6.3 at 1.5–2.0) plus
  **0.5 a side** (0.8 on the east). The terminals and pins reach out to x −7.72..7.23, but only up to 1.5 over the
  board, 2.95 under the lid's underside, so they do not size it. The board floats 0.25 in the case, so the
  body keeps at least 0.25 from the opening's edge wherever it sits. There is no nut clamp, no bushing
  hole and no pad ring any more.
- **What holds the board**: the perimeter ledge under it (the south one stops either side of the UPDI pads)
  and **four lid posts**, Ø3.0, coming down to 0.1 over the board top at **(±18, ±8)**. That puts them on bare
  board in the four corners beyond the encoder: 0.52 from J1/J2's courtyards (the nearest parts) and 0.50 from the
  board edge (the script asserts both). The same posts as lp_arc4.
- **What keeps the board square is the cavity alone** (board + 0.25 a side). The lid no longer locates the
  encoder, so the board can shift 0.25 and turn by about 0.6°. J1/J2 sit in end slots 1.02 wider a side than
  their bodies, so they do not locate it. Turning the knob puts its torque through the encoder's pins into the
  board, and the cavity walls take it.
- **The body height question goes away.** The tails set the board (underside 2.45) and the GHs set the lid
  (underside 8.5), so the top is 10.0 whatever the body. With the board model's 4.2 the frame top is at 8.25,
  1.75 under the lid surface. With the openGrid cases' 6.5 it is at 10.55 and **stands 0.55 proud of the lid**.
  `--body 6.5` runs every check, and 10.0 and 6 pockets hold for both.
- **Stack**, desk up: tails 0.20, PCB 2.45–4.05, J1/J2 to 8.30, lid 8.50–10.0, encoder frame 8.25 (4.2 body) or
  10.55 (6.5 body).
- **Knob.** The shaft tip is 20.2 above the frame (the H20): 28.45 above the desk with a 4.2 body, 30.75 with a
  6.5 body. A typical 15 × 16 knob with its top 1.5 over the tip stands 13.95–29.95 (4.2 body). Its skirt is
  3.95 over the lid, 3.45 pressed at 0.5 travel and 2.45 at 1.5 travel (the EC11 series figure). With the 6.5
  body the knob is 16.25–32.25 and the skirt is 5.70 over the proud frame (5.20 / 4.20 pressed). Either way the
  skirt is nowhere near the opening's edge, and the script asserts it. The Ø15 skirt is wider than the opening's
  12.7 width, so a knob pushed right down would land on the opening's long edges. **Keep it above the lid by
  more than the travel**: with this knob, cut the shaft no more than about 2 mm.
  For comparison, a keycap top on lp_mx4rgb (plate at 10.0) is about 24.5 for DSA, 26.5 for Cherry R3 and
  28.5 for OEM R3 (the picture's stand-in is 21.3). So the knob stands 1.5–5.5 above the keycaps with a 4.2
  body. A lower-skirted or shorter knob closes that more safely than cutting the shaft.
- **Cables leave at z 4.05–8.30 through both ends**, centred on the case's centre line. Each end has a 12.8-wide
  slot, plus a 16-wide finger relief through the lid outside the board edge (the openGrid case's cuts, started
  at 3.85 so the end pockets keep their solid). That is the high-window band: **`straight` (or `corner`) carries
  the lead**, keyed to the enc1's end. Like the disp2, a case keyed directly at a used end blocks its lead unless
  it has a slot there.
- **Fit check** (the script runs it), each part against base and lid:
  - every footprint's courtyard × its STEP height (front parts), or a 0.1 stand-in (the pads on the back);
  - the PCB;
  - the encoder as the board STEP's own solid, and as boxes: courtyard × 1.5 for the terminals, body outline ×
    `ENC_BODY_H`, bushing, shaft, tails;
  - J1/J2 with a corridor out past the case edge;
  - then every solid of the board STEP.

  **No overlap, for both body heights.** Margins:

  | Margin | mm |
  |---|---|
  | Tails to the desk | 0.20 |
  | Tails to the floor window's side | 0.50 |
  | Body to the lid opening, board centred (board pushed over) | 0.50 (0.25) |
  | Bushing to the opening | 2.85 |
  | Terminals under the lid | 2.95 |
  | Post to the board top | 0.10 |
  | Post to J1/J2's courtyards | 0.52 |
  | Post to the board edge | 0.50 |
  | GH top to the lid | 0.20 |
  | GH body to its slot side | 1.02 |
  | End slot over the pocket's solid zone | 0.05 |
  | Latch tab over the board | 1.25 |

  **Controls:**

  | Control | What it finds |
  |---|---|
  | No floor window | the tails in the floor, 157 mm³ |
  | No lid opening | the encoder in the lid: STEP solid 58 mm³ and bushing 58 mm³ (4.2 body); body box 216 mm³ (6.5 body) |
  | Opening 1 mm too small a side, a body standing through the lid | the body in the lid, 31 mm³ |
  | The same body through the real opening | nothing, as it should |
- **The lead, checked.** `lp_enc1_preview.png` is lp_mx4rgb, a `straight` block and the enc1 in a row, two keys.
  The J1 lead is modelled as a GH plug (8.0 × 4.3, 5.0 past the mouth, assumed), then a 3.3 bundle at the plug's
  height through the block's high windows, jogging to mx4rgb's J2 slot line (z 5.1–8.4) and into it: **no
  overlap** with any base or lid. Control: a `corner` block in the same place finds its east wall (27 mm³).
  A plug threaded through a high window has 0.5 a side and 0.15 above and below.
- **Print without supports.**
  - **Base:** floor-down. The end slots and reliefs are open to the top, and the pocket roofs are the usual
    0.85 bridges.
  - **Lid:** top-down, with posts and latch tabs up (the STL is flipped). The opening is a through-hole, so
    there is nothing to bridge.
- **Assembly**: plug both leads in, drop the board on its ledges with the tails through the window, snap the lid
  down over the encoder: the posts bear on the board's corners. The encoder's nut is not used; leave it off, or
  run it down onto the frame only as a spacer for the knob.

### Assumed, not measured: measure these before printing

| What | Value | Why it matters here |
|---|---|---|
| Encoder body outline above 1.5 over the board | 12.3 × 11.7 (board STEP) | The lid opening is this plus 0.5 a side. A wider frame on the bought part and the lid touches it; check it fits through the opening with 0.25 to spare when the board is pushed over |
| `ENC_BODY_H`, board top to the frame top | 4.2 (board STEP; the openGrid cases assume 6.5; the part is not chosen) | No longer sets the case. It sets how far the frame stands proud (−1.75 or +0.55) and the knob height |
| Encoder tails under the board | 2.25 (STEP) | Only 0.20 to the desk. Longer and the case rocks on them; trim them or raise `TAIL_GAP` |
| Shaft | tip 20.2 above the frame | The knob height |
| Push travel, knob | 0.5 (1.5 also checked); 15 × 16, top 1.5 over the tip | The knob's skirt must stay above the lid, or a proud frame, when pressed |
| Board thickness | 1.6 | The posts come to 0.1 over it. Thicker and the lid will not seat |
| GH plug outside the receptacle | 8.0 × 4.3, 5.0 past the mouth | The lead check and the high windows |
| `LINK_CLR` | 0.10 | As every low-profile case: tune on a print |

Printed and tested (Daniel, 2026-11-24).

## disp1: `lp_disp1.py`

A low-profile case for the **v1 disp1 board as built** (50 × 20, every part on the front, J1/J2 included, and a
0.91" 128 × 32 OLED module over the back on four wires from J3). Native to the low-profile numbers, as lp_disp2
and lp_enc1 are. Board and module facts come from `../tile-disp1/case/disp1_case.py` (unchanged), part heights
from the board's `.kicad_pcb` and STEP. The STEP has no module, so the module is disp1_case.py's assumed one:
38 × 12, PCB 1.2, glass 34 × 11.5 × 1.4, active area 22.4 × 5.6 centred.

    python lp_disp1.py . [--render]      # base + lid STEP/STL, fit check, lead path, controls (about 2 min); --render: PNGs
    python lp_disp1.py . --gap 2.95      # the same checks for another wire room under the module (nothing written)

- **The board goes in upside down**, as in the openGrid case: front (J1/J2) to the desk, back (module) to the lid.
- **Footprint 2 × 1, 55.5 × 27.5, but 12.04 tall: 2.04 over the system's 10.0.** The board puts J1/J2 (4.29
  deep, board STEP) on one face and the module on the other, so they stack. Stack, desk up: J1/J2 0.20–4.49 in
  **floor windows** open to the end walls (as lp_disp2), PCB 4.49–6.09, **wire room 2.5** (disp1_case.py's
  `MOD_GAP_MIN`), module 8.59–9.79, glass to 11.19, lid lip 0.85. J3 is at the board's centre and the module's
  pins are at one of its ends, so the four wires run about 16 mm flat under the module. Holding 10.0 would need
  0.46 of wire room with the glass under a lip, or 1.31 with the glass flush and bare; neither is a fold four
  wires and their joints make. Only a board change fixes it (module and GHs on the same face, or the GHs on the
  edge). It stands 0.32 lower than lp_mx1rgb_1x1 (12.36), for the same reason. The openGrid case gives the
  wires 2.95: `--gap 2.95` makes it 12.49.
- **How the module is held.** By the lid, as in the openGrid case. A pocket in the lid's underside (the module
  outline + 0.3) takes the glass up against a 0.85 lip. A frame round the module hangs below the lid; two lips
  under the module's long edges (0.8 thick, 0.2 under the edge, as the openGrid case) click past it, leaving
  0.05 of play. Both short frame walls are notched 10 wide for the wires. The **window is the active area + 1.2**
  (24.8 × 8.0, the openGrid margin, kept because where the lit area sits on the module is not measured), so the
  lip bears on 1.75 or more of glass border and nothing touches the active area. Four posts under the lid
  clamp the board's back corners onto ledges under its north and south edges. The south ledge stops either side
  of C4.
- **4 link pockets of 6**: both long sides at both cells. The end walls have none, because each end's desk-level
  opening (13.2 wide, from the desk to the board) sits on the end's only cell edge, where the pocket would go.
- **Fit check** (the script runs it): every front part's courtyard × its STEP depth, the back's test pads, the PCB,
  J1/J2 with a cable corridor out past the case edge, what replaces J3's header (joints and trimmed tails under
  the front, the four wires flat on the back to a pin row at either end of the module and rising into it, their
  joints on the module's top), the module PCB, the glass, and the active area's line of sight. Each is
  intersected with base and lid, then every solid of the board STEP the same way. **No overlap**, except the
  STEP's J3 pin header, which goes through the floor (1.6 mm³). It is not fitted, as in the openGrid case.
  Margins: J1/J2 to the desk 0.20, GH to the side of its opening 1.22, C4 to the floor 2.20, wires (1.0 OD) under
  the frame 0.70 and 0.49 inside the lips, module-top joints under the pocket ceiling 0.40, post to frame 1.90,
  snap tab over the board's back 1.25. **Controls:** with no floor windows, J1/J2 hit the floor (75 mm³ each).
  With no lid window, the active area's line of sight hits the lid (107). With no module pocket, the glass hits
  the lid (125).
- **Leads leave at desk level through both ends**, centred on the end's cell edge (GH section ±5.38, z
  0.20–4.45). **None of the five link blocks takes that.** A 1x1's high windows start at 3.9, and `2x1_disp2`'s
  desk window is on its long side's middle, a grid line, 14 mm off a cell centre. As on the disp2, a case keyed
  directly at a used end blocks the lead, so leave that cell open. What would carry it: **a 1x1 with
  `2x1_disp2`'s desk window (13.2 wide, desk to 4.8) on the side facing the disp1**, plus a high window onward.
  It is the mirror of `corner` with its north window lowered to the desk, and it takes 3 pockets of 4. It is
  **not built**. The script adds it to `lp_link_block.VARIANTS` in memory, for the lead check and the picture,
  and writes no file for it.
- **The lead, checked.** `lp_disp1_preview.png`: lp_mx4rgb on cells 0–2, the proposed block on (3, 0), and the
  disp1 turned 90° on (3, 1–2) with J1 north and its west side keyed to mx4rgb's east end. That is 2 keys, and no
  case overlaps another. J1's section runs into the block's desk window, then a 3.3 lead on its floor, up, and west
  through the high window into mx4rgb's J2 slot (z 5.1–8.4). **No overlap** with any base or lid. The plug has
  1.22 a side and 0.35 above in the desk window. Control: the existing `corner`, turned 90° (high windows S and
  W) in the same place, finds the plug in its south wall (82 mm³).
- **Print without supports**: base floor-down. Each end opening's roof is the end wall bridging 13.2 at z 4.49,
  as lp_disp2. Pocket roofs are the usual bridges. Lid top-down (STL flipped): the lip is the first layers, the
  module pocket is open upward, and the clip lips are 0.5 overhangs at the top of the frame walls.
- **Assembly**: program the board first (the test pads face the lid). Solder the module's four wires into J3's
  holes with no header, and trim the tails under the front. Plug both leads in, drop the board onto the ledges
  back up with the plugs through the floor windows, press the module face down into the lid's frame until the
  lips click, fold the wires flat under it, and snap the lid on.

### Assumed, not measured: measure these before printing

| What | Value | Why it matters here |
|---|---|---|
| Module PCB, glass (`MOD_PCB_T`, `GLASS_T`, `MOD_L`, `MOD_W` in disp1_case.py) | 1.2, 1.4; 38 × 12; glass 34 × 11.5 | The pocket, frame and lips are cut for them, and the top follows their sum |
| Where the active area sits on the module (`WIN_DX`) | centred | The 1.2 window margin is the slack for this |
| Wire room the four wires need, flat, with their bends (`--gap`) | 2.5 | Sets the top. 1.0 OD wires are assumed; thinner wire does not lower the case unless `--gap` comes down |
| The module's pin row | 1.0 from one end, at either end | Where the wires rise; the joints on its top have 0.40 under the lid |
| J3 joints and tails under the front | 1.5 | 1.99 to the floor |
| GH plug and lead | the receptacle's section; a 3.3 lead | The lead check |
| `LINK_CLR` | 0.10 | As every low-profile case: tune on a print |

Printed and tested (Daniel, 2026-11-24).

## arc4: `lp_arc4.py`

A low-profile case for the **v1 arc4 board as built** (r2, 50 × 25; J3–J6 side-entry `S3B-PH-SM4-TB` along the
north edge, mouths north; J1/J2 GH on the front at the ends, 6.0 south of the centre line). **The board only:
the arcade buttons are not in the case.** Native to the low-profile numbers, as lp_enc1 and lp_disp2 are. Board
facts from `../tile-arc4/tile-arc4.kicad_pcb` and its STEP.

    python lp_arc4.py . [--render]       # base + lid STEP/STL, fit check, lead path, controls; --render: PNGs

- **Why the board only.** The repo names no button part and no depth: §47 says the board "carries nothing sized
  by an actuator: the buttons are on leads", and the docs say the buttons are panel-mounted and the tile sits
  behind the panel. A low-profile case is 10.0 from desk to top, and a snap-in arcade button with its
  microswitch hangs far more than that under its panel (typically 20–35 mm, not a repo figure). So the buttons
  go in a panel (or the openGrid arc4 setup) and their leads come back to this case. A lid that held buttons
  would be a box as deep as the button, which is not a low-profile case.
- **Footprint 2 × 1, 55.5 × 27.5 × 10.0**, the openGrid arc4 case's footprint. **2 link pockets of 6**, one
  on each end at the centre line. The north and south walls are 1.1 (a 25 board in 27.5), too thin for one.
- **Stack**, desk up: floor 1.0, PCB 2.45–4.05 on a perimeter ledge, J1/J2 to 8.34, PH bodies to 9.59, lid
  8.5–10.0. The board stands at lp_enc1's height on purpose: the J1/J2 slots overlap the end pockets in plan
  (the GHs are 6.0 off the centre line), so they have to start at 3.85, above the pockets' solid zone. Nothing
  is on the back but the UPDI pads, which get a floor window so a pogo jig can reach them in the case.
- **The lid is a U.** The PH bodies stand 5.54 over the board, above a 1.5 lid's underside, so the lid has a
  window over the PH row, open to its north edge (the openGrid `--vertical` lid's window, X 101.4–148.6 from
  Y 110.9). The bodies sit in it 0.41 under the top. The window is also how you grip a PH plug, which has no
  latch. The arms either side carry the end latches; a third latch is on the south wall. Two Ø3 posts under
  the lid's south strip stop 0.1 over bare board south of J3/J6, so the board cannot lift when a plug is pulled.
  No pry notch: the window and the J1/J2 reliefs leave the lid's edges open.
- **Button leads leave north.** The north wall and its rim are open over all four PH plugs from z 3.85 up; the
  wall below holds the PCB's north edge (1.4 of its 1.6) against a pull. The plug backs stand 2.65 past the
  case's north face (with the assumed 5.0 of plug past the mouth), so they can be gripped and pulled straight
  out. **Keep the cell row north of an arc4 free**: a case keyed there would close off the leads.
- **Strain relief**: the openGrid lid's tie tunnel (two 1.8 × 4.0 slots 7 apart, ties to about 3.6 wide), here
  in a boss hanging to 7.0 under the lid's south strip, 2.95 over the board. Fold the leads back south over
  the lid and tie them; nothing goes through the lid's underside, so the lid still comes off.
- **Bus leads leave through both ends** at z 4.05–8.35, in a 12.8 slot centred on the GH (6.0 south), with a
  finger relief through the lid outside the board edge (lp_enc1's cuts). **No existing link block takes them**:
  every high window is 9.0 and centred, and the GH plug (8.0 wide) arrives at −10…−2. What would:
  **`straight-s4`, a 1x1 like `straight` with both side windows 13.2 wide (the "wide" window, z 3.9–8.5) centred
  4.0 south** (y −10.6…2.6). It takes the plug with 0.6 to spare on the south and 0.15 above and below, still
  passes a centred lead, keeps all 4 pockets, and is the same both ways, so one part serves either end. **Not
  built**: the script adds it to `lp_link_block.VARIANTS` in memory for the lead check and the picture, and
  writes no file for it. As with disp1 and disp2, a case keyed directly at a used end blocks the lead.
- **Fit check** (the script runs it): every front footprint's courtyard × its STEP height, the UPDI pads, the
  PCB, J1/J2 with a cable corridor out past the case edge, and each of J3–J6 as a plug pull path (the PH body's
  section from its back to 10 past the north face: plug, plug drawn out, and lead), each against base and lid,
  then every solid of the board STEP. **No overlap.** Margins: PH body to the window's end 0.65 and to its south
  edge 2.20, PH to the end latch tab 1.08, GH top to the lid 0.16, GH body to its slot side 1.02, end slot over
  the pocket's solid zone 0.05, latch tab over the board 1.25, tie boss over the board 2.95, post to board 0.10.
  **Controls**: with no north opening the four plug paths hit the base (56.7 mm³ each); with no lid window the
  four PH bodies hit the lid (125 each); with no end slots J1/J2's corridors hit the base (120 each).
- **The lead, checked.** `lp_arc4_preview.png`: lp_mx4rgb on cells 0–2, `straight-s4` on (3, 0), the arc4 on
  (4–5, 0); 2 keys, no case overlaps another. J1's GH plug (8.0 × 4.3, 5.0 past the mouth, assumed), then a
  3.3 lead through the block, jogging to mx4rgb's J2 slot line (z 5.1–8.4) and into it: **no overlap**.
  Control: the existing `straight` in the block's place finds the plug and lead in its east wall (17 + 21 mm³).
- **Print without supports**: base floor-down (the end slots, reliefs and north opening are open to the top;
  pocket roofs are the usual bridges). Lid top-down (STL flipped): posts, boss and latch tabs up; the tie
  tunnel's roof is the boss's 0.8 floor bridging 8.8, as in the openGrid lid.
- **Assembly**: program the board (or do it later through the floor window), plug the GH leads, drop the board
  onto the ledge, snap the lid in, plug the four PH leads from the north, fold them back and tie them.
- The window is the openGrid `--vertical` lid's, so the 2026-11 boards with vertical PH parts may fit too, with
  their plugs rising through it. Not checked.

### Assumed, not measured: measure these before printing

| What | Value | Why it matters here |
|---|---|---|
| PH plug past the receptacle mouth (`PH_PLUG_OUT`) | 5.0; its section taken as the body's, 9.9 × 5.54 | Grip room past the north face (2.65 as assumed) and the plug paths |
| PH lead (`PH_LEAD`) | 3 wires flat, 6.5 × 2.0 | Picture only; the pull path is the full body section |
| PH body height | 5.54 (board STEP) | Over 5.95 and the bodies stand proud of the lid |
| GH plug and lead | 8.0 × 4.3, 5.0 past the mouth; a 3.3 lead | The lead check and the proposed block's window |
| Board thickness | 1.6 | The posts stop 0.10 over it |
| South and end latches | the openGrid arc4 case's; the south groove leaves 0.5 of the 1.1 wall | Printed and tested (Daniel, 2026-11-24). |
| `LINK_CLR` | 0.10 | As every low-profile case: tune on a print |

Printed and tested (Daniel, 2026-11-24).

## screenkey1, in two cases: `lp_screenkey.py`

![The module case with the board case south of it](lp_screenkey_preview.png)

The board and the ScreenKey module in separate cases, joined by the 9-pin lead, as
`../tile-screenkey1/case/sk1_split_case.py` does on openGrid. Both cases have link pockets on every cell edge (6 and 8),
so they key to each other and to the rest like any low-profile case.

- **Board case** (`lp_sk1_board_*`), 2x1, top 10.0. The board stands on ledges under its ends, PCB at 3.5–5.1
  (U5 hangs 2.25 under it, 0.25 over the floor). J1/J2 open at the ends. J3 opens through the north wall and the
  lid, as in `sk1_case.py`, because the plug and its latch stand taller than the lid's underside. The lid's tabs are
  1.5 long, so they stay 0.34 over the front parts at the board's edges.
- **Module case** (`lp_sk1_module_*`), 2x2. The module lies along x, against the north wall, with its socket edge
  south. Its switch plate sits flush in the lid's opening, 0.3 clear all round, as an MX plate does. Its four brass
  standoffs press into sockets in bosses on the floor, with 0.6 of floor under each, as in `sk1_4x2_case.py`. The
  plug stands out into a bay 17.8 × 50.3 south of it, which is room to coil the 200 mm lead. The lead leaves
  through a window in the south wall, the same 19 wide as the board case's J3 window. The lid closes the window
  over the lead.
- **Side by side**: put the board case on the 2x1 south of the module case, J3 north. The J3 window and the cable
  window then line up across the joint, and the lead goes straight across. The cases also work apart, within the
  lead's reach.
- **Height is set by the standoffs.** With the 8.0 standoffs the module comes with, the plate top is 12.0, 2.0 over
  the other cases, like lp_mx1rgb_1x1 (12.36) and lp_disp1 (12.04). With 6.0 M2 standoffs instead,
  `--standoff 6` gives 10.0, level with the rest. The module's back parts still clear the bosses, checked against
  Waveshare's STEP.
- **Assembly**: module into the base (standoffs into the bosses), plug the lead in, lay it in the bay and out
  through the window, then snap the lid on over the plate.
- **Checked**: the board's STEP against the board case and Waveshare's STEP against the module case. No overlap,
  with either standoff length. The assumed plug envelopes also clear both cases.

```
python lp_screenkey.py <outdir> [--standoff 6] [--module "<0.85inch ScreenKey Module B .stp>"] [--render]
```

![Exploded](lp_screenkey_exploded.png)

### Assumed, not measured: measure these before printing

| What | Value | Why it matters here |
|---|---|---|
| PicoBlade 9-pin plug | 13.5 wide, 6.5 past the mouth, 4.0 tall with its latch | The J3 window through the lid, the bay |
| Standoff press fit | `sk1_case.py`'s socket (round on the hex's corners, 0.10 over) | What holds the module down: tune on a print |
| Lead | the supplied 200 mm (r1 boards need it reversed, IMPLEMENTATION.md §34.17) | Coils in the bay |
| `LINK_CLR` | 0.10 | As every low-profile case: tune on a print |

Not in the layout planner yet. Printed and tested (Daniel, 2026-11-24).

## stick1: `lp_stick1.py`

The openGrid stick1 case (`../tile-stick1/case/stick1_case.py`) at the low-profile top, as lowpro.py makes the
MX cases: the script runs unchanged against `mm_case` at 10.0 with the snaps stubbed out.

    python lp_stick1.py <outdir> [<RKJXV1224005.stp>]   # base + lid STEP/STL, the checks, lp_stick1_assembly.step

- **2 × 2, 55.5 × 55.5 × 10.0, 8 link pockets of 8.** The openGrid walls are 1.6, so a block (9.6 wide, 3.5 in
  from the edge, 4.0 tall) thickens the wall at each cell-edge midpoint for its pocket. The blocks stop 0.9 short
  of the board's fences and under the latch grooves.
- **The board stays on its 1.6 floor**, PCB 1.6–3.2, because the stick's tails need the 1.2 pocket under it.
- **The stick does not come down.** Its top frame stands at 14.4, 4.4 over the lid, in the lid's 26.4 opening,
  and the lever tip at 22.15. The part sets this tile's height, as the encoder does enc1's.
- **The bowl is recomputed for the lower lid**: r 13.2–14.75, lowest 8.86, its shell's underside 7.66, 4.46 over
  the board. The cap swept to full tilt in eight directions touches nothing.
- **Checked**: the board STEP (it has no stick: SamacSys's model may not be redistributed) against base and lid,
  no overlap; a block stand-in for the stick (16 square to the frame, the lever to its tip), no overlap. Pass
  SamacSys's model to check the real stick.
- **Assumed, as in the openGrid case**: where the cap sits on the lever (`CAP_RIM_BELOW_TIP` 7.2). Measure a real
  cap. Nothing here has been printed.
