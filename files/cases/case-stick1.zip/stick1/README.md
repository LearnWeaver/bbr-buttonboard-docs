# tile-stick1 openGrid case

A 2x2 openGrid case for the 44 × 25 stick1 board: 55.5 × 55.5 × 15.0 mm, plus four snaps 3.4 mm deep. The stick
takes a PS2/Xbox-style dome cap (18 mm pad, 25 mm skirt, 15 mm tall), and the lid sinks into a round well round it,
like the shell round a controller's stick. With the cap on, the top is about 30 mm above the openGrid face.
`stick1_case.py` (CadQuery) builds it from the board's KiCad coordinates and reuses the snap, the flush lid and
the latches from `../../main-module-xiao/case/mm_case.py`. Run `python3 stick1_case.py .`

- **Why 2x2.** On the lever, the cap's 25 mm skirt sits right at 15.0, the top every case shares
  (IMPLEMENTATION.md §56). Tilted the full 23°, it swings down to about 9.7 and out about 14 mm from the stick
  centre. A 2x1 tile is 27.5 mm deep, too narrow to clear that.
- **The well is computed, not drawn.** The script sweeps the cap's outer profile through every tilt up to 23° in
  every direction, takes the lowest point it reaches at each radius, and leaves 0.8 mm clear of it. The result is
  a round opening 29.5 mm across. Its floor, a 1.2 mm shell, follows the skirt's path down to 8.9, and the wall
  round it is solid out to 1.6 mm beyond the opening (`RIM_T`): measured straight down only, a near-vertical
  wall was a fraction of a millimetre thick and the slicer dropped it. The script
  then sweeps the cap to full tilt in eight directions and checks it touches nothing.
- **The board lies flat on the floor,** in the middle of the square, held by low fences. The ALPS stick is tall
  (top frame 11.2 above the PCB) and the back of the board carries only through-hole tails and three bare test
  pads. The stick's top frame and pot housings rise into the lid's height; the well's 26.4 mm centre opening
  clears them.
- **Tail pocket**: a 1.2 mm pocket in the floor under the stick takes its tails, leaving 0.4 mm of floor. The six
  potentiometer pins stand 1.3 mm below the board, so **trim those to 1.2 mm or less** after soldering; the frame
  tabs, the locating pegs and the switch pins are short enough as they are.
- **Lid**: 1.5 mm, flush. Snap tabs on the north and south walls (x −20..−8 and 8..20), pry notch in the south rim
  at x = 0.
- **Posts**: four posts hang from the lid's underside to the board's top face, one in each corner along the long
  edges (6.4 × 3.0 at the west end, 7.0 × 3.0 at the east), so the lid holds the board flat on the floor. They
  land on bare board: J1/J2's housings, U1's capacitors, the right pocket's parts and the stick all keep at least
  0.5 mm away, checked against KiCad's 3D export. They also stay clear of the well and the J1/J2 slots. They
  are drawn to touch a 1.6 mm board (`POST_GAP` 0); raise `POST_GAP` if a print binds when the lid snaps on.
- **J1 and J2**: at the board's ends, with slots out through the end walls and the usual latch relief.
- **Assembly**: solder and trim the stick, drop the board in, snap the lid on, push the cap onto the lever.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped, and the well's wall then
  stands up from the bed.
- The back-side UPDI test pads are covered by the base, so program the board before casing it.

## Assumed, not measured

**Where the cap sits on the lever.** A seller's picture gives the cap's outside but not how far its skirt's rim
sits below the lever's tip once pushed fully on. `CAP_RIM_BELOW_TIP` (7.2) is a guess, and the well's depth follows
it. Measure a real cap: push it on and measure from the rim to the lever's tip (or from the board to the rim and
subtract from 18.95). Set `CAP_RIM_BELOW_TIP`, and the outline in `CAP_PROFILE` if the cap's shape differs, then
rerun. The well reshapes itself and the sweep check confirms it.

## Where the stick numbers come from

ALPS's RKJXV1224005 drawing gives the top frame 11.2 above the PCB, the lever tip 18.95, the lever Ø4 (3 across its
flats) and 23° of tilt each way. The pivot height (6.6) is scaled off its side view; it sets the cap's sweep.

SamacSys's RKJXV1224005 model (Component Search Engine; a copy is in greghulette/KiCad-Files-Public on GitHub)
agrees with that drawing and gives the stick's outline and tail lengths. Every tail in it lands in one of
`BBR:Joystick_ALPS_RKJXV`'s holes: the pot pins (0.8 × 0.3) in the 1.0 holes, the switch pins in the 1.2 holes
(0.07 mm off centre), the frame tabs in the 1.5 holes, and two Ø1.5 locating pegs in the 1.6 holes at x ±4.3. Its
licence forbids redistributing the model, so it is not in the repo. `python3 stick1_case.py <outdir>
<RKJXV1224005.stp>` checks the case against it.

Check the heights and the tails on a real stick before printing.
