# back-plate: cable cover for the back of the openGrid board

Leads that drop through the board hang loose behind the panel. This is a flat cover that holds them:
a plate the size of the board, standing 5 mm off its back face on snap-in standoffs. `back_plate.py`
(CadQuery) builds both parts and reuses the openGrid snap from `../main-module-xiao/case/mm_case.py`.

Run `python3 back_plate.py . [--cols N] [--rows N] [--gap MM]` (default 5 × 5, 5 mm). It writes
`back_plate_<cols>x<rows>.step/.stl`, `back_plate_standoff.step/.stl`, and
`back_plate_<cols>x<rows>_assembly.step` (the plate with a standoff in each corner and the centre, for
Fusion). It checks that each part is one valid solid and that a standoff clears the plate. The STEP and STL
files are build output, so do not commit them.

- **Plate:** `cols × 28` by `rows × 28` mm, 2.0 mm thick, with a 12.6 mm hole on **every** cell centre. So a
  standoff can go in any cell, around the cells a drop tile or drop snap already takes.
- **Standoff:** a back snap on a 27.5 mm flange, 1.6 mm thick, with a hollow post. The post ends in four
  split prongs carrying a barb: push the plate down over the posts and each one clicks through its hole.
  A ledge under the plate sets the gap. To take the plate off, squeeze the prongs of each post together.
- **The post is hollow, 10.4 mm bore**, through the post, the flange and the snap, so a GH plug passes on
  edge. A lead can come through the board at a standoff cell too, so a standoff never costs a drop
  position.
- **Gap 5.0 mm** from the board's back face to the plate: twisted leads, and a GH plug lying flat
  (4.3 mm) with 0.7 mm to spare. It is 3.4 mm over a standoff's flange. The 3.75 mm low cable tiles
  (`../cable-1x1 --low`) fit under it, with 1.25 mm to spare. It was 8.0 mm in the first version.
- **Clip:** the prongs are 1.0 mm thick and 5.0 mm long, and the barb stands 0.4 mm proud (0.3 mm of it
  catches the plate, past the hole's 0.1 mm clearance). That is about 2.4 % peak strain going in: at the
  top of PLA's 2–3 %, so print the standoffs in PETG if PLA ones crack. The 5 mm gap is what limits the
  prong length. The script prints the figure for whatever gap you build. Tune `HOLE_D` (12.5–12.8) to
  your printer: too tight and the barb will not pass, too loose and the plate rattles.
- **Print:** the standoff snap-down, on the bed, as every case; the ledge's underside is at 45° and the
  barb's catch is a 0.4 mm overhang, so it needs no supports. The plate is flat.
- **How many:** four in the corner cells hold a 5 × 5 plate. Add one near the middle if the leads push
  it out.
- **Needs a full openGrid board.** Like the low tiles, the standoff snaps into the board's back. A lite
  board is single-sided and has no back to snap into.

**On the docs site:** `getting-started/back-plate.md` has a generator that builds the plate for any size
in the browser and stretches the standoff for a larger gap (`docs/gitbook/files/back-plate/`). This script
stays the source: `python3 back_plate.py . --docs ../../docs/gitbook/files/back-plate` writes the numbers it
reads (`backplate-params.json`) and the default-gap standoff STL, which are committed like the case zips.
Rerun it after changing a parameter here, then `node tools/test_generators.mjs`, which checks the browser's
plate against this script's volumes and that every mesh is watertight. `tools/case_downloads.py back-plate`
rebuilds the 5 × 5 zip on the cases page.

Not printed or fitted yet: the clip fit and the snap's hold from the back are unproven.
