# tile-disp2 openGrid case

A 2x2 openGrid case for the 50 × 40 disp2 board: 55.5 × 55.5 × 15.0 mm, plus four snaps 3.4 mm deep.
`disp2_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 disp2_case.py .`

- **Lid = bezel.** A 1.5 mm plate with a 35.6 × 28.6 window over the panel's active area. It is flush with
  the walls at 15.0 mm, the top every case shares (IMPLEMENTATION.md §56), and drops into a pocket 0.8 mm in
  from the outside. The window is off centre (east) because the flex end of the glass is its wide border.
  The lid's underside sits on the glass's border all round, at least 2.5 mm of it, so the panel is clamped
  as well as glued.
- **Snap latches**: two hooked tabs, x −10 to 10 on the north and south walls. The board comes within 0.2 mm
  of every wall and its top is only 3.0 mm under the lid, less than a tab's 3.2, so each tab hangs in a 2 mm
  recess cut into the thick wall, outboard of the board. A pry notch in the east end lifts the lid out.
  Nothing hangs from the lid on the west side, where the panel's flex loops out past the glass edge.
- **Base**: everything except the panel is on the back of the board. The lid's underside is the glass top,
  13.5 mm, so the board is set by the stack under it: PCB 8.9–10.5 (it was 6.35–7.95), 7.3 mm off the floor,
  well clear of J1/J2 (4.25 mm). It rests on a ledge along its north edge, and on the south edge either side
  of the test-pad row, so it never sits on its own pads.
- **Cables**: J1 and J2 are on the back at the west and east edges, mouths out. Both end walls are open under
  the board, 4.75 mm tall up to its underside, so each plug goes in from the side, as on tile-mx1-1x1.
- **Assembly**: glue the panel and solder its flex first. Plug both cables in, drop the board onto the ledges,
  and snap the lid in. The lid presses the glass down.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped.
- The back-side test pads are covered by the base, so program the board before casing it.

## Assumed, not measured

The board's height is set by the stack under the lid, and two numbers in it are guesses:

| Constant | Value | What to measure |
|---|---|---|
| `PANEL_T` | 2.5 mm | the glass and backlight together, edge to edge |
| `TAPE_T` | 0.5 mm | the foam tape or glue under the glass, as fitted |

Too high and the board sits too low, so the lid floats above the glass. Too low and the lid presses on it.
Measure a glued-up board (glass top to board top) and set `PANEL_T + TAPE_T` to that.
