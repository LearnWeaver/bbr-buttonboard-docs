# tile-mx1rgb openGrid case

A 2x1 openGrid case for the 40 × 20 mx1rgb board: 55.5 × 27.5 × 15.0 mm, plus two snaps 3.4 mm deep.
`mx1rgb_case.py` (CadQuery) builds it from the board's KiCad coordinates. It reuses the snap from
`../../main-module-xiao/case/mm_case.py`. Run `python3 mx1rgb_case.py .`

- **Lid = switch plate.** The lid is 1.5 mm thick with a 14.0 mm MX cutout over the key centre (120, 110).
  Its top is 5.0 mm above the PCB, the MX standard. The switch clips into the lid, so key presses load the case, not the board.
- **Top**: flush, 15.0 mm above the openGrid face like every case (IMPLEMENTATION.md §56). The plate drops into a
  pocket 0.8 mm in from the outside and snaps in on two hooked tabs, x −9..9 on the north and south walls, between
  the connector slots. A pry notch in the west end, south of J1, lifts it out.
- **Base**: the board rests on ledges under its two short ends, its underside 8.4 mm up. That leaves 6.8 mm under the key for the
  hot-swap socket, the switch's centre post and the reverse-mounted SK6812MINI-E. Board clearance is 0.15 mm,
  tighter than the other cases, so the plate cutout lines up with the socket.
- **J1 and J2**: they are 4.25 mm tall, more than the 3.5 mm under a plate (IMPLEMENTATION.md §39.3), so the case
  is open above them. The plug drops in from the end and its latch can be reached from above.
- **Assembly**: board into the base, snap the lid in, then push the switch through the lid into the socket.
  Pull the switch before taking the lid off.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped. If the switch is loose,
  set `PLATE_HOLE` to 13.9. If it won't seat, set it to 14.1.
- The back-side UPDI test pads are covered by the base, so program the board before casing it.
