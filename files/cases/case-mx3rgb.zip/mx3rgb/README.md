# tile-mx3rgb openGrid case

A 3x1 openGrid case for the 66 × 22 mx3rgb board: 83.5 × 27.5 × 15.0 mm, plus three snaps 3.4 mm deep.
`mx3rgb_case.py` (CadQuery) builds it from the board's KiCad coordinates. It is the mx1rgb case design with
three keys, and it reuses the snap from `../../main-module-xiao/case/mm_case.py`. Run `python3 mx3rgb_case.py .`

- **Lid = switch plate.** The lid is 1.5 mm thick with three 14.0 mm MX cutouts at x 114 / 133.05 / 152.1, y 110,
  on a 19.05 mm pitch. Its top is 5.0 mm above the PCB. The switches clip in, so key presses load the case.
- **Top**: flush, 15.0 mm above the openGrid face like every case (IMPLEMENTATION.md §56). The plate drops into a
  pocket 0.8 mm in from the outside and snaps in on four hooked tabs, x −24..−12 and 12..24 on the north and south
  walls. A pry notch in the west end, south of J1, lifts it out.
- **Base**: the board rests on ledges under its two short ends, its underside 8.4 mm up. That leaves 6.8 mm under the keys for the
  sockets, the switch centre posts and the three reverse-mounted SK6812MINI-E. Board clearance is 0.15 mm.
- **J1 and J2**: the case is open above them (IMPLEMENTATION.md §39.3). The plug drops in from the end and its
  latch can be reached from above.
- **Assembly**: board into the base, snap the lid in, then push the switches through into the sockets.
  Pull the switches before taking the lid off.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped. Tune `PLATE_HOLE` (13.9–14.1)
  once the mx1rgb case shows how your printer holds a switch.
- The back-side UPDI test pads are covered by the base, so program the board before casing it.
