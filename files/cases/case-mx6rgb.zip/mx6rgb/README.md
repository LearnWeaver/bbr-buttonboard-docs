# tile-mx6rgb openGrid case

A 3x3 openGrid case for the 60 × 60 mx6rgb board: 83.5 × 83.5 × 15.0 mm, plus nine snaps 3.4 mm deep. Like
every case, its top is at 15.0 mm and the lid sits flush in the walls (IMPLEMENTATION.md §56).
`mx6rgb_case.py` (CadQuery) builds it from the board's KiCad coordinates, following the mx4 case, and reuses
the snap and the flush top from `../../main-module-xiao/case/mm_case.py`. Run `python3 mx6rgb_case.py .`

- **Lid = switch plate.** The lid is 1.5 mm thick with six 14.0 mm MX cutouts on the 19.05 mm pitch, at x
  110.95 / 130 / 149.05 and y 110.95 / 130. Its top is 5.0 mm above the PCB, so the switches clip in and key
  presses load the case.
- **Base**: the board rests on ledges under its west and east edges, with its top at z 10.0. That leaves
  6.8 mm under it for the hot-swap sockets, the switch centre posts and the reverse-mounted SK6812MINI-E LEDs.
  Board clearance is 0.15 mm.
- **Walls are thick**: a 60 mm board in an 83.5 mm cell leaves 11.6 mm all round. So the four latch tabs hang
  in pockets inside the north and south walls, 1.6 mm in from the outside, at x −20..−8 and 8..20, clear of
  the board altogether. A pry notch in the east end, at y 15, lifts the lid out.
- **J1 and J2**: they sit at the west and east ends of the electronics band along the south edge. The case
  is open above them and through the end walls (IMPLEMENTATION.md §39.3), so the plug drops in from the end
  and its latch can be reached from above.
- **Assembly**: board into the base, snap the lid in, then push the switches through into the sockets. Pull
  the switches before taking the lid off.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped. Tune `PLATE_HOLE`
  (13.9–14.1) to your printer, as on the other key cases.
- **Checked** against `../tile-mx6rgb.step` at the board's height: no overlap with the base; the lid meets
  only the switch models passing through their plate holes.
