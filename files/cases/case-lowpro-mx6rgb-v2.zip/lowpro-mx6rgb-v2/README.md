# tile-mx6rgb-v2 cases

Low-profile and openGrid cases for the 66 × 41 v2 board (`../`), on 3 × 2 cells: **83.5 × 55.5 × 10.0 mm** low profile,
**83.5 × 55.5 × 15.0** on openGrid (plus its snaps). `mx6rgb_v2_case.py` says what the board is; the design is
`../../v2_mx_case.py`, shared by the v2 multi-key boards. **Nothing here has been printed, and the board has not been
fabricated.**

    kicad-cli pcb export step --user-origin 133x120.5mm --subst-models -f -o board.step ../tile-mx6rgb-v2.kicad_pcb
    python mx6rgb_v2_case.py <outdir> [board.step] [--opengrid] [--full] [--render]

![low profile](mx6rgb_v2_case_lowpro_preview.png)

- **Lead bays.** J1/J2 are on the centre line of the north row of cells. That cell of each end is cut back 6.0 mm, as
  lp_mx3rgb's ends are: 2.6 of wall is left, and 6.25 to the grid line, 4.0 of it past the plug's tail (assumed 5.0),
  for the lead to turn in. The rest of each end reaches the grid line. `--full` leaves the ends whole.
- **Low profile**: link pockets in 8 of 10 cell edges; the two without are the bays, which no key could reach.
- **openGrid**: a snap in every cell. The bays keep a 1.6 floor over theirs, so the lead lies on it.
- **Lid = switch plate**, 1.5 mm, flush, two tabs on each long wall, pry notch in the west end. The J1/J2 slots run
  0.15 into the end switches' plate holes, as lp_mx3rgb's do: stopping short leaves a 0.15 web. The edges the
  switches' clips hold on are whole.
- **Checked** against the board STEP, both styles: nothing overlaps but the switches in their plate holes (0.7 and
  10.7 mm³ each, as every MX case); the lowest part is 0.27 over the low-profile floor; the tabs flexed 0.6 in meet
  nothing; a plug in each connector is clear and reachable from above; a link key fits every pocket.
- **Print** the base as it stands, the lid top-down (the STL is flipped). Program the board first: its pads face the floor.
- **Assumed**: the plug's tail, `LINK_CLR` and the plate hole. Tune on a first print.
