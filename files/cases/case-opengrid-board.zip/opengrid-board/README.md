# opengrid-board: the full openGrid board, no screw holes

The board every case snaps into. `opengrid_board.py` (CadQuery) builds a `cols × rows` **full** openGrid
board: 6.8 mm thick and symmetric front to back, so the back plate (`../back-plate`) and the low cable
tiles (`../cable-1x1 --low`) can snap into its back. It has **no screw bosses and no edge connectors**:
the panel is not screwed to anything, and one board is one print.

Run `python3 opengrid_board.py . [--cols N] [--rows N]` (default 5 × 5). It writes
`opengrid_full_<cols>x<rows>.step/.stl` and checks the board is one valid solid. The STEP and STL files
are build output, so do not commit them.

- **Cell profile:** `opengrid_cell_void()` from morganp/openscad-opengrid (MIT), an implementation of the
  published openGrid dimensions. Flats 25.8 mm at each face, a 0.4 mm 45° chamfer to the 25.0 mm land, then
  out to the 26.4 mm retaining groove at 2.4 mm deep; mirrored for the back face. It is the same profile the
  cases' snaps (`og_snap()` in `../main-module-xiao/case/mm_case.py`) are sized against.
- **Edges:** the outermost walls are half a rib, 1.1 mm at the face and 0.8 mm at the groove, as on any
  openGrid board. Handle a big board by its middle until it is on the wall.
- **On the docs site:** `getting-started/opengrid-board.md` has a generator that builds the board for any
  size in the browser (`docs/gitbook/files/opengrid-board/`). This script stays the source:
  `python3 opengrid_board.py . --docs ../../docs/gitbook/files/opengrid-board` writes the numbers it reads
  (`opengrid-params.json`, with this script's volume for the size built). Rerun it after changing the
  profile, then `node tools/test_generators.mjs`, which checks the browser's board is watertight and
  matches that volume exactly. `tools/case_downloads.py opengrid-board` rebuilds the 5 × 5 zip.

openGrid is CC BY 4.0, by David D (https://www.printables.com/model/1214361). openGrid compatible, not
official.
