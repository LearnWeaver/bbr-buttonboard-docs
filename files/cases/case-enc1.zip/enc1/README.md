# tile-enc1 openGrid case

A 2x1 openGrid case for the 44 × 20 enc1 board: 55.5 × 27.5 × 15.0 mm, plus two snaps 3.4 mm deep.
`enc1_case.py` (CadQuery) builds it from the board's KiCad coordinates. It is the enc2 case design cut to one
encoder, and it reuses the snap from `../../main-module-xiao/case/mm_case.py`. Run `python3 enc1_case.py .`

- **Base**: the board drops onto a 1.5 mm perimeter ledge, its underside 4.85 mm up. That leaves 3.25 mm under it for the encoder's pin tails and mounting lugs.
- **Top**: flush, 15.0 mm above the openGrid face like every case (IMPLEMENTATION.md §56). The 2 mm lid drops into a
  pocket 0.8 mm in from the outside and snaps in on two hooked tabs, x −10..10 on the north and south walls. A pry
  notch in the west end lifts it out.
- **Lid**: The encoder's M7 bushing passes through a Ø7.4 hole
  at the board centre (122, 110). The encoder nut then clamps the lid onto the encoder body, so the board hangs from the lid.
- **J1 and J2**: each gets a 12.8 × 4.85 window through the last 1.0 mm of wall, with a 16 mm relief outside it for the latch.
- **Print**: base floor-down, snaps on the bed. Lid top-down; the STL is already flipped.
- **Assumed, not measured**: the case assumes an EC11E body 6.5 mm tall and a bushing that leaves at least 3 mm of thread above
  the 2 mm lid, the same as the enc2 case. KiCad's EC11E model disagrees: its frame is 4.2 mm tall and its bushing ends
  2.15 mm above the lid (2.65 with the chamfer). Change `ENC_BODY_H` and `LID_T` once the part is chosen; the board
  moves, the top stays at 15.0.
- The back-side UPDI test pads are covered by the base, so program the board before casing it.
